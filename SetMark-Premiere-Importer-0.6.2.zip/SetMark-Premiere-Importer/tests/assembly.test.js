"use strict";
const test = require("node:test"), assert = require("node:assert/strict");
const core = require("../plugin/core.js"), { layout, createAssembly, sourceFormat, roundTicks, collectSelection } = require("../plugin/assembly.js");
const raw = JSON.stringify({ id: "shoot", title: "新時間線", format: "29.97 DF", lookback: 0, marks: [
  { id: "a", frame: 215734, lookbackFrames: 90, tag: "爆笑" },
  { id: "b", frame: 216044, lookbackFrames: 90, tag: "金句" }
] });
const f = core.format("29.97 DF"), ticks = n => String(BigInt(n) * BigInt(f.timebase));
function fixture() {
  let markerFailure = false;
  let created = [], active = null, wrong = false, dropAudio = false, failInsert = false, failDelete = false;
  const duration = item => String(BigInt(item.frames) * BigInt(sourceFormat(item.rate).timebase));
  function source(id, start, frames) {
    const item = { id, name: id, start, frames, rate: 30000/1001, offline: false, trim: 0, hasAudio: true,
      getId: () => id, isSequence: async () => false, isMergedClip: async () => false, isMulticamClip: async () => false,
      isOffline: async () => item.offline, getComponentChain: async type => type === "video" || item.hasAudio ? {} : null,
      getMediaFilePath: async () => "/media/" + id + ".mp4", getFootageInterpretation: async () => ({ getFrameRate: () => item.rate }),
      getInPoint: async () => ({ ticks: ticks(item.trim) }), getOutPoint: async () => ({ ticks: duration(item) }) };
    return item;
  }
  const clips = [source("B",216084,90), source("A",215784,90)]; let selected = clips; let root = {getId:()=>"root",name:"Project",getItems:async()=>clips};
  const old = { guid: { toString: () => "old" } }; active = old;
  function track(item, position, lane = 0, audio = false) { return { lane, getProjectItem: async () => item, getStartTime: async () => ({ ticks: ticks(position + (wrong ? 1 : 0)) }),
    getDuration: async () => ({ ticks: audio ? duration(item) : ticks(roundTicks(duration(item), f.timebase)) }), getInPoint: async () => ({ ticks: "0" }) }; }
  function sequence(name, first) {
    const s = { name, zero: "0", display: f.display, guid: { toString: () => name }, videos: first.audioOnly ? [] : [track(first,0)], audios: [track(first,0,0,true)], timebase: sourceFormat(first.rate).timebase,
      getTimebase: async () => s.timebase, getZeroPoint: async () => ({ ticks: s.zero }),
      getSettings: async () => ({ setVideoFrameRate: async rate => { s.timebase=String(rate.ticksPerFrame); return true; }, setVideoDisplayFormat: async display => { s.display=display.type; return true; } }),
      getSequenceVideoTimeDisplayFormat: async () => ({ type: s.display }), createSetSettingsAction: () => () => {},
      createSetZeroPointAction: time => () => { s.zero=time.ticks; },
      getVideoTrackCount: async () => Math.max(0,...s.videos.map(t=>t.lane))+1, getAudioTrackCount: async () => Math.max(0,...s.audios.map(t=>t.lane))+1,
      clearSelection: async()=>{s.selection=[];}, getSelection:async()=>({addItem:item=>s.selection.push(item),items:s.selection}),
      getVideoTrack: async i => ({ getTrackItems: () => s.videos.filter(t=>t.lane===i) }), getAudioTrack: async i => ({ getMediaType: async () => "standard", getTrackItems: () => dropAudio ? [] : s.audios.filter(t=>t.lane===i) }) };
    return s;
  }
  const project = { getRootItem: async()=>root, guid: { toString: () => "project" }, getActiveSequence: async () => active,
    getInsertionBin: async () => ({}), createSequenceFromMedia: async (name, media) => { const s=sequence(name,media[0]); created.push(s); active=s; return s; },
    executeTransaction: fn => { const actions=[]; fn({ addAction: a => actions.push(a) }); for(const a of actions)a(); return true; },
    lockedAccess: fn => fn(), openSequence: async s => { active=s; return true; }, setActiveSequence: async s => { active=s; return true; },
    deleteSequence: async s => { if(failDelete)return false; created=created.filter(x=>x!==s);return true; } };
  const ppro = { FrameRate: {createWithValue: value => ({value})}, Project: { getActiveProject: async () => project }, ProjectUtils: { getSelection: async () => ({ getItems: async () => selected }) },
    Constants: { MediaType: { VIDEO: "video", AUDIO: "audio" } }, ClipProjectItem: { cast: async item => item }, FolderItem: {cast: async item => item.getItems ? item : null},
    Metadata: { getProjectColumnsMetadata: async item => JSON.stringify([
      { ColumnID: "Column.Intrinsic.MediaStart", ColumnValue: ticks(item.start) },
      { ColumnID: "Column.Intrinsic.MediaEnd", ColumnValue: String(BigInt(ticks(item.start))+BigInt(duration(item))) },
      { ColumnID: "Column.Intrinsic.MediaDuration", ColumnValue: duration(item) }
    ]) }, TickTime: { createWithTicks: ticks => ({ ticks }) }, SequenceEditor: { getEditor: s => ({ createRemoveItemsAction: (sel,ripple,type)=>()=>{if(type==="video")s.videos=s.videos.filter(i=>!sel.items.includes(i));else s.audios=s.audios.filter(i=>!sel.items.includes(i));}, createInsertProjectItemAction: (item,time,v,a) => () => {
      if(failInsert)throw Error("insert failure"); const position=Number(BigInt(time.ticks)/BigInt(f.timebase));if(!item.audioOnly)s.videos.push(track(item,position,v)); if(item.hasAudio)for(let ch=0;ch<(item.audioWidth||1);ch++)s.audios.push(track(item,position,a+ch,true));
    } }) } };
  const markerHost = { preview: async raw => {
    const data=core.parse(raw); const s={ projectID: "project", sequenceID: active.name, timebase:f.timebase, display:active.display, zero:active.zero, end:ticks(Math.max(...selected.map(c=>c.start+roundTicks(duration(c),f.timebase)))-Math.min(...selected.map(c=>c.start))), markers:[] };
    return { state:s, plan:core.plan(data,s) };
  }, commit: async review => { if (markerFailure) throw Error("marker failure"); return review.plan.additions.length; } };
  return { api:createAssembly(ppro,markerHost), markerFailure:()=>{markerFailure=true;}, clips, created:()=>created, active:()=>active, old, source,
    root: x=>{root=x;}, select: x=>{selected=x;}, wrong:()=>{wrong=true;}, dropAudio:()=>{dropAudio=true;}, failInsert:()=>{failInsert=true;}, failDelete:()=>{failDelete=true;} };
}
test("all formats create exact nonzero origin with gaps and compensated marks", () => {
  for(const name of Object.keys(core.FORMATS)) {
    const spec=core.format(name), data=core.parse(JSON.stringify({id:"p",format:name,marks:[{id:"m",tag:"NG",frame:950,lookbackFrames:90}]}));
    const clips=[{id:"b",name:"b",start:1300,frames:90,rate:spec.num/spec.den},{id:"a",name:"a",start:1000,frames:90,rate:spec.num/spec.den}];
    const result=layout(data,clips,"project");
    assert.equal(result.state.zero,String(1000n*BigInt(spec.timebase))); assert.equal(result.plan.additions[0].frame,40);
    assert.equal(result.clips[1].start-result.clips[0].start,300);
  }
});
test("new sequence is built from earliest clip and preserves gap and audio", async () => {
  const m=fixture(), review=await m.api.preview(raw);
  assert.equal(m.created().length,0); assert.equal(review.plan.startTC,"02:00:00;00");
  const result=await m.api.commit(review,raw); assert.equal(result.count,2); assert.equal(m.created().length,1);
  assert.equal(m.active().zero,ticks(215784)); assert.equal((await m.active().videos[1].getStartTime()).ticks,ticks(300));
});
test("selection change, invalid source and source in/out points stop before building", async () => {
  const m=fixture(), review=await m.api.preview(raw);
  m.select(m.clips.slice(1)); await assert.rejects(m.api.commit(review,raw),/已變更/); assert.equal(m.created().length,0);
  m.clips[1].trim=1; await assert.rejects(m.api.preview(raw),/入出點/);
  m.clips[1].trim=0; m.clips[1].offline=true; await assert.rejects(m.api.preview(raw),/離線/);
});
test("cross-midnight and frame-rate mismatch are rejected", async () => {
  const m=fixture();
  m.clips[0].start=f.day-10; await assert.rejects(m.api.preview(raw),/跨午夜/);
  m.clips[0].start=216084; m.clips[0].rate=27; await assert.rejects(m.api.preview(raw),/影格率/);
  assert.equal(m.created().length,0);
});
test("bad native placement, missing audio and insert failure preserve diagnostic sequence", async () => {
  for(const failure of ["wrong","dropAudio","failInsert"]) {
    const m=fixture(), review=await m.api.preview(raw); m[failure]();
    await assert.rejects(m.api.commit(review,raw),/已保留時間線.*請勿直接用於剪輯/); assert.equal(m.created().length,1); assert.equal(m.active(),m.created()[0]);
  }
});
test("failed marker import preserves assembled clips and explains retry", async () => {
  const m=fixture(), review=await m.api.preview(raw); m.markerFailure();
  await assert.rejects(m.api.commit(review,raw),/素材核對已完成.*已加入的標記會略過/); assert.equal(m.created().length,1);
});

test("overlapping sources occupy separate video and audio tracks", async () => {
  const m=fixture(); m.clips[0].start=m.clips[1].start;
  const review=await m.api.preview(raw); assert.equal(review.lanes.length,2);
  await m.api.commit(review,raw);
  assert.deepEqual(m.active().videos.map(t=>t.lane),[1,0]);
  assert.deepEqual(m.active().audios.map(t=>t.lane),[1,2]);
});
test("eight cameras reuse their own lanes across card folders and retain longest duration", () => {
  const data=core.parse(raw), clips=[];
  for(let i=0;i<8;i++) for(let card=0;card<2;card++) clips.push({id:i+"-"+card,name:"clip",path:"/video/"+String.fromCharCode(65+i)+"機/A00"+card+"/clip.mp4",start:1000+card*1000,frames:i===0?900:100,rate:30000/1001});
  const review=layout(data,clips,"p"); assert.equal(review.lanes.length,8);
  for(let i=0;i<8;i++) assert.equal(review.clips[i].videoTrack,review.clips[8+i].videoTrack);
  assert.equal(review.state.end,ticks(1900));
});

test("59.94 first source converts to 29.97 sequence without doubling duration", async () => {
  const m=fixture(); m.clips[1].rate=60000/1001; m.clips[1].frames=180;
  const r=await m.api.preview(raw); assert.equal(r.clips[0].frames,90);
  await m.api.commit(r,raw); assert.equal(await m.active().getTimebase(),f.timebase);
  assert.equal((await m.active().videos[0].getDuration()).ticks,ticks(90));
  assert.equal((await m.active().audios[0].getDuration()).ticks,ticks(90));
});
test("mixed 24 and 29.97 durations use exact ticks and only quantize video frames", async () => {
  const m=fixture(); m.clips[0].rate=24; m.clips[0].frames=72;
  const r=await m.api.preview(raw); assert.equal(r.clips[1].frames,90);
  assert.equal(r.clips[1].sourceDurationTicks,String(3n*254016000000n));
  await m.api.commit(r,raw);
});
test("half-frame and long-duration conversions round once without accumulated drift", () => {
  const half=BigInt(f.timebase)/2n;
  assert.equal(roundTicks(half.toString(),f.timebase),1);
  assert.equal(roundTicks((half*21578401n).toString(),f.timebase),10789201);
  for(const rate of [24000/1001,24,25,30000/1001,30,50,60000/1001,60]) assert.ok(sourceFormat(rate));
  assert.throws(()=>sourceFormat(27));
});

function bin(id,name,items=[]) { return {getId:()=>id,name,getItems:async()=>items}; }
test("selected parent recursively collects eight cameras and cards; overlapping selections deduplicate", async()=> {
  const cameras=[], selected=[];
  for(let i=0;i<8;i++) cameras.push(bin("cam"+i,String.fromCharCode(65+i)+"機",[bin("card"+i,"A001",[{getId:()=>"clip"+i,name:"clip"}])]));
  const root=bin("root","Project",[bin("video","video",cameras)]);
  const ppro={FolderItem:{cast:async i=>i.getItems?i:null}};
  const result=await collectSelection(ppro,{getRootItem:async()=>root},[root,cameras[0]]);
  assert.equal(result.length,8); assert.equal(new Set(result.map(x=>x.group)).size,8);
  assert.equal(result[0].label,"A機");
});
test("Bin preview detects moved or renamed bins and newly added sources before commit",async()=> {
  const m=fixture(), children=[...m.clips], a=bin("a","A機",children), root=bin("root","Project",[a]);
  m.root(root);m.select([root]); const r=await m.api.preview(raw);
  a.name="B機"; await assert.rejects(m.api.commit(r,raw),/已變更/); assert.equal(m.created().length,0);
});
test("empty bin and selection outside project stop without creating sequence",async()=>{
  const m=fixture(), empty=bin("empty","Empty"),root=bin("root","Project",[empty]);
  m.root(root); m.select([empty]);await assert.rejects(m.api.preview(raw));
  m.select([bin("missing","Gone")]);await assert.rejects(m.api.preview(raw),/已移動/);
  assert.equal(m.created().length,0);
});
test("same-name Bin identities stay distinct; nested card bins share camera ancestor",async()=>{
  const m=fixture(),a=bin("a","A機",[bin("card1","A001",[m.clips[0]])]),b=bin("b","A機",[m.clips[1]]),root=bin("root","Project",[a,b]);
  m.root(root);m.select([root,a,m.clips[0]]);
  const r=await m.api.preview(raw);assert.equal(r.clips.length,2);assert.equal(r.lanes.length,2);
});
test("sequences inside selected bins are skipped and reported",async()=>{
  const m=fixture();const seq={getId:()=>"seq",name:"Existing sequence",isSequence:async()=>true};
  const root=bin("root","Project",[...m.clips,seq]);m.root(root);m.select([root]);
  const r=await m.api.preview(raw); assert.equal(r.clips.length,2);assert.equal(r.skipped.length,1);
});

test('LTC audio is included without adding video lanes and missing copies stop', async()=> {
 const m=fixture(); const a=m.clips[0];
 a.getComponentChain=async type=>type==='audio'?{}:null;
 a.getMediaFilePath=async()=>'/prepared/mic.wav';
 const data=JSON.parse(raw);data.ltcAudio={version:1,format:data.format,clips:[{path:'/prepared/mic.wav',startTicks:ticks(a.start),durationTicks:ticks(a.frames)}]};
 const r=await m.api.preview(JSON.stringify(data));
 assert.equal(r.lanes.length,1);assert.equal(r.clips.filter(c=>c.audioOnly).length,1);
 data.ltcAudio.clips[0].path='/missing.wav';await assert.rejects(m.api.preview(JSON.stringify(data)),/全部 LTC/);
});
test('LTC rejects changed duration, duplicate paths and mismatched format',async()=> {
 const m=fixture(), a=m.clips[0];a.getComponentChain=async type=>type==='audio'?{}:null;a.getMediaFilePath=async()=>'/mic.wav';
 const data=JSON.parse(raw);data.ltcAudio={version:1,format:data.format,clips:[{path:'/mic.wav',startTicks:ticks(a.start),durationTicks:ticks(100)}]};
 await assert.rejects(m.api.preview(JSON.stringify(data)),/長度/);
 data.ltcAudio.clips.push(data.ltcAudio.clips[0]);await assert.rejects(m.api.preview(JSON.stringify(data)),/重複/);
 data.ltcAudio.format='25';await assert.rejects(m.api.preview(JSON.stringify(data)),/格式/);
});

test('CardDock A camera is visually above B and Pocket regardless of start order',async()=> {
 const items=['PA','Bcam','Acam'].map((name,i)=>({getId:()=>name,name}));
 const tree=bin('root','Project',[bin('day','D01',[bin('video','VIDEO',items.map((item,i)=>bin('camera'+i,item.name,[bin('card'+i,'001',[item])]))),bin('meta','_CARD_METADATA',[{getId:()=> 'thumb',name:'thumb'}])])]);
 const entries=await collectSelection({FolderItem:{cast:async i=>i.getItems?i:null}},{getRootItem:async()=>tree},[tree]);
 assert.equal(entries.length,3);
 const r=layout(core.parse(raw),entries.map((e,i)=>({...e,id:e.item.getId(),name:e.item.name,start:1000+i*100,frames:90,rate:30000/1001})), 'p');
 assert.deepEqual(r.lanes.map(l=>l.label),['PA','B機','A機']);
 assert.equal(r.clips.find(c=>c.name==='Acam').videoTrack,2);
});
test('LTC audio commits onto audio tracks only and retains video positions', async()=> {
 const m=fixture(),a=m.clips[0];a.audioOnly=true;a.getComponentChain=async type=>type==='audio'?{}:null;a.getMediaFilePath=async()=>'/mic.wav';
 const d=JSON.parse(raw);d.ltcAudio={version:1,format:d.format,clips:[{path:'/mic.wav',startTicks:ticks(a.start),durationTicks:ticks(a.frames)}]};
 const r=await m.api.preview(JSON.stringify(d));await m.api.commit(r,JSON.stringify(d));
 assert.equal(m.active().videos.length,1);assert.equal(m.active().audios.length,2);
});

async function sameCamera(m) {
  const camera = bin("camera", "A機", m.clips);
  m.root(bin("root", "Project", [camera]));
  // Keep clip selection for the marker-host fixture while using real parent ancestry.
  return m.api.preview(raw);
}
test("same camera nonoverlapping multichannel clips reuse the complete audio block", async()=> {
  const m=fixture(); for(const c of m.clips)c.audioWidth=4;
  await m.api.commit(await sameCamera(m),raw);
  assert.deepEqual(m.active().audios.map(x=>x.lane),[1,2,3,4,1,2,3,4]);
});
test("same camera overlapping audio receives a separate block", async()=> {
  const m=fixture(); m.clips[0].start=m.clips[1].start+30;
  for(const c of m.clips)c.audioWidth=2;
  await m.api.commit(await sameCamera(m),raw);
  assert.deepEqual(m.active().audios.map(x=>x.lane),[1,2,3,4]);
});
test("different channel widths do not share a block", async()=> {
  const m=fixture(); m.clips[0].audioWidth=2;m.clips[1].audioWidth=4;
  await m.api.commit(await sameCamera(m),raw);
  assert.deepEqual(m.active().audios.map(x=>x.lane),[1,2,3,4,5,6]);
});
test("different cameras keep separate audio blocks even without overlap", async()=> {
  const m=fixture();
  m.root(bin("root","Project",m.clips.map(c=>bin(c.id+"bin",c.id+"機",[c]))));
  await m.api.commit(await m.api.preview(raw),raw);
  assert.deepEqual(m.active().audios.map(x=>x.lane),[1,2]);
});
test("audio ending between video frames reserves its full duration", async()=> {
  const m=fixture();m.clips[1].rate=24;m.clips[1].frames=73;
  m.clips[0].start=m.clips[1].start+91;
  await m.api.commit(await sameCamera(m),raw);
  assert.deepEqual(m.active().audios.map(x=>x.lane),[1,2]);
});

test("500 consecutive four-channel clips retain four occupied audio tracks", async()=> {
  const m=fixture();m.clips.splice(0,m.clips.length);
  for(let i=0;i<500;i++){const c=m.source("clip"+i,215784+i*100,90);c.audioWidth=4;m.clips.push(c);}
  await m.api.commit(await sameCamera(m),raw);
  assert.equal(m.active().audios.length,2000);
  assert.deepEqual([...new Set(m.active().audios.map(x=>x.lane))],[1,2,3,4]);
});
