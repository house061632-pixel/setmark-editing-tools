"""Run in Resolve's Python console after setting FILE to an exported SetMark JSON.
Requires a timeline laid out against the same source timecode, with matching FPS/DF.
No clips are moved. Existing markers are never overwritten.
"""
import json
import re
from collections import defaultdict

FORMATS = {
    '23.976': (24, 24000/1001, 0), '24': (24, 24, 0), '25': (25, 25, 0),
    '29.97 NDF': (30, 30000/1001, 0), '29.97 DF': (30, 30000/1001, 2),
    '30': (30, 30, 0), '50': (50, 50, 0),
    '59.94 NDF': (60, 60000/1001, 0), '59.94 DF': (60, 60000/1001, 4), '60': (60, 60, 0)
}

def tc_frames(tc, nominal, drop):
    values = list(map(int, re.findall(r'\d+', tc)))
    if len(values) != 4:
        raise ValueError('無法讀取時間軸起始時間碼')
    h, m, s, f = values
    if h >= 24 or m >= 60 or s >= 60 or f >= nominal or (drop and m % 10 and s == 0 and f < drop):
        raise ValueError('時間碼不符合專案格式')
    minutes = h * 60 + m
    return ((h * 3600 + m * 60 + s) * nominal + f) - drop * (minutes - minutes // 10)

def read_shoot(file_path):
    with open(file_path, encoding='utf-8') as handle:
        shoot = json.load(handle)
    if not isinstance(shoot, dict): raise ValueError('不是有效的 SetMark 專案檔')
    if shoot.get('isTest') is True:
        raise ValueError('這是模擬時間碼的功能測試紀錄，不能對應正式相機素材')
    if not isinstance(shoot, dict) or not isinstance(shoot.get('id'), str) or shoot.get('format') not in FORMATS:
        raise ValueError('不是有效的 SetMark 專案檔')
    marks = shoot.get('marks')
    if not isinstance(marks, list) or len(marks) > 100000:
        raise ValueError('標記清單無效或超過 100000 筆')
    seen = set()
    for mark in marks:
        if not isinstance(mark, dict) or not isinstance(mark.get('id'), str) or not mark['id'] or mark['id'] in seen:
            raise ValueError('標記識別碼無效或重複')
        seen.add(mark['id'])
        if type(mark.get('frame')) is not int or not isinstance(mark.get('tag'), str) or not isinstance(mark.get('note', ''), str):
            raise ValueError('標記時間碼、分類或備註格式無效')
    # Validate every compensation before any new timeline can be created.
    import math
    lookback = shoot.get('lookback', 0)
    if type(lookback) not in (int, float) or not math.isfinite(lookback) or not 0 <= lookback <= 3600:
        raise ValueError('往前保留設定無效')
    for mark in marks:
        if not isinstance(mark.get('author', ''), str): raise ValueError('標記姓名格式無效')
        value = mark.get('lookbackFrames', 0)
        if type(value) is not int or not 0 <= value <= 216000: raise ValueError('標記的往前保留設定無效')
    return shoot

def import_marks(resolve, file_path, apply=False, timeline_override=None):
    shoot = read_shoot(file_path)
    nominal, rate, drop = FORMATS[shoot['format']]
    project = resolve.GetProjectManager().GetCurrentProject()
    timeline = timeline_override if timeline_override is not None else (project.GetCurrentTimeline() if project else None)
    if not timeline:
        raise ValueError('請先開啟 Resolve 專案與已按來源時間碼排列的時間軸')
    settings = timeline.GetSettings() if hasattr(timeline, 'GetSettings') else timeline.GetSetting()
    fps = re.search(r'\d+(?:\.\d+)?', str(settings.get('timelineFrameRate', '')))
    if not fps or abs(float(fps.group()) - rate) > 0.01:
        raise ValueError('Resolve 時間軸幀率與 SetMark 專案不一致')
    df = settings.get('timelineDropFrameTimecode')
    if df is None:
        raise ValueError('無法確認時間軸 DF/NDF 設定，已停止匯入')
    if (str(df).lower() in ('1', 'true')) != bool(drop):
        raise ValueError('Resolve 時間軸 DF/NDF 與 SetMark 不一致')
    start = tc_frames(timeline.GetStartTimecode(), nominal, drop)
    # Restore the button-press time once, using each mark's captured lookback.
    # Legacy files only carry the project-wide setting.
    lookback = shoot.get('lookback', 0)
    if type(lookback) not in (int, float) or lookback < 0 or lookback > 3600:
        raise ValueError('往前保留設定無效')
    compensation = int(round(float(lookback) * rate))
    length = timeline.GetEndFrame() - timeline.GetStartFrame()
    day = nominal * 86400 - drop * 1296
    if length <= 0: raise ValueError('時間線沒有可用範圍')
    if length >= day:
        raise ValueError('原型僅支援少於 24 小時的時間軸')
    grouped = defaultdict(list)
    skipped = []
    for mark in shoot['marks']:
        per_mark = mark.get('lookbackFrames', compensation)
        if type(per_mark) is not int or per_mark < 0 or per_mark > 216000:
            raise ValueError('標記的往前保留設定無效')
        relative = (int(mark['frame']) + per_mark - start) % day
        if 0 <= relative < length:
            grouped[relative].append(mark)
        else:
            skipped.append(mark['id'])
    existing = timeline.GetMarkers() or {}
    results = {'planned': 0, 'added': 0, 'already_present': 0, 'conflicts': [], 'out_of_range': skipped, 'failed': []}
    colors = {'爆笑': 'Yellow', '金句': 'Cyan', '衝突': 'Red', '反應': 'Green', 'NG': 'Pink', '備註': 'Blue', '其他': 'Blue', '開機': 'Cyan'}
    for frame, marks in sorted(grouped.items()):
        identity = 'setmark:v2:' + shoot['id'] + ':' + ','.join(sorted(m['id'] for m in marks))
        if frame in existing:
            if existing[frame].get('customData') == identity:
                results['already_present'] += 1
            else:
                results['conflicts'].append(frame)
            continue
        results['planned'] += 1
        if apply:
            name = ' / '.join(dict.fromkeys(m['tag'] for m in marks))
            note = '\n'.join((m.get('author') or '') + ' · ' + m['tag'] + ': ' + m.get('note', '') for m in marks)
            ok = timeline.AddMarker(frame, colors.get(marks[0]['tag'], 'Blue'), name, note, 1, identity)
            if ok: results['added'] += 1
            else: results['failed'].append(frame)
    return results

# Resolve Python console example:
# exec(open('/absolute/path/import_markers.py').read())
# print(import_marks(resolve, '/absolute/path/SetMark-....json'))  # Preview only
# print(import_marks(resolve, '/absolute/path/SetMark-....json', apply=True))


"""Integrated source-timecode assembly. Concatenated into the single install script."""
import os
import hashlib
from fractions import Fraction

def media_rate(value):
    match = re.search(r'\d+(?:\.\d+)?', str(value))
    if not match: raise ValueError('無法讀取素材影格率。')
    value = float(match.group())
    for n, d in [(24000,1001),(24,1),(25,1),(30000,1001),(30,1),(50,1),(60000,1001),(60,1)]:
        if abs(value - n/d) < .01: return Fraction(n,d)
    raise ValueError('不支援的素材影格率；請使用固定影格率原始影片。')

def nearest_frame(value):
    return (value.numerator * 2 + value.denominator) // (value.denominator * 2)

def frame_tc(frame, nominal, drop):
    if drop:
        ten = nominal * 600 - drop * 9
        blocks, rest = divmod(frame, ten)
        frame += drop * 9 * blocks + drop * max(0, (rest - drop) // (nominal * 60 - drop))
    seconds, f = divmod(frame, nominal)
    minutes, sec = divmod(seconds, 60)
    hours, minute = divmod(minutes, 60)
    return f'{hours:02}:{minute:02}:{sec:02}{";" if drop else ":"}{f:02}'


def media_bin_index(pool):
    """Keep bin identity, including camera ancestors above card sub-bins."""
    index = {}
    root = pool.GetRootFolder()
    def values(items):
        return list(items.values()) if isinstance(items, dict) else (items or [])
    def walk(folder, ancestors):
        chain = ancestors + [folder]
        candidates = chain[1:]
        camera_bins = [b for b in candidates if re.fullmatch(
            r'(?:[A-Za-z0-9]+[ _-]*機(?:位)?|機位[ _-]*[A-Za-z0-9]+|(?:cam|camera)[ _-]*[A-Za-z0-9]+|[A-Za-z0-9]+[ _-]*(?:cam|camera))',
            b.GetName().strip(), re.IGNORECASE)]
        owner = camera_bins[-1] if camera_bins else (folder if ancestors else None)
        for clip in values(folder.GetClipList()):
            index[clip.GetUniqueId()] = {'folder': folder,
                'group': 'bin:' + owner.GetUniqueId() if owner else None,
                'label': owner.GetName() if owner else None,
                'path': [(b.GetUniqueId(), b.GetName()) for b in chain]}
        for child in values(folder.GetSubFolderList()): walk(child, chain)
    walk(root, [])
    return index

def source_plan(resolve, file_path):
    shoot = read_shoot(file_path)
    nominal, rate, drop = FORMATS[shoot['format']]
    project = resolve.GetProjectManager().GetCurrentProject()
    if not project: raise ValueError('請先開啟 Resolve 專案。')
    pool = project.GetMediaPool()
    selected = pool.GetSelectedClips()
    if not selected: raise ValueError('請先在媒體池選取相機素材，再按「檢查標記」。')
    if isinstance(selected, dict): selected = list(selected.values())
    bins = media_bin_index(pool)
    source_folders = {}
    clips = []
    seen = set()
    for clip in selected:
        props = clip.GetClipProperty()
        name = clip.GetName()
        if props.get('Type') not in ('Video', 'Video + Audio'):
            raise ValueError(name + '：請選取原始影片，不支援圖片、純音訊或巢狀時間線。')
        uid = clip.GetUniqueId()
        if uid in seen: raise ValueError('選取素材有重複。')
        seen.add(uid)
        path = props.get('File Path', '')
        if not path or not os.path.isfile(path): raise ValueError(name + '：素材離線或不是一般影片檔。請先連結原始素材。')
        source_rate = media_rate(props.get('FPS', ''))
        target_rate = media_rate(rate)
        raw_frames = str(props.get('Frames', ''))
        if not raw_frames.isdigit() or int(raw_frames) <= 0: raise ValueError(name + '：無法讀取完整素材長度。')
        tc = str(props.get('Start TC', ''))
        if not re.fullmatch(r'\d{2}:\d{2}:\d{2}[:;]\d{2}', tc): raise ValueError(name + '：缺少可辨識的來源時間碼。')
        source_nominal = round(source_rate)
        source_drop = (2 if source_nominal == 30 else 4) if ';' in tc and source_rate.denominator == 1001 and source_nominal in (30,60) else 0
        if ';' in tc and not source_drop: raise ValueError(name + '：素材時間碼與影格率不相容。')
        if source_rate.denominator == 1001 and source_nominal in (30,60) and bool(drop) != bool(source_drop):
            raise ValueError(name + '：素材 DF／NDF 與 JSON 不一致，請核對共用時間碼。')
        # Resolve media-pool Start TC is interpreted at the media playback rate,
        # not at the camera LCD's potentially half-rate TC display.
        source_start = Fraction(tc_frames(tc, source_nominal, source_drop), 1) / source_rate
        source_duration = Fraction(int(raw_frames), 1) / source_rate
        frame = nearest_frame(source_start * target_rate)
        timeline_frames = nearest_frame(source_duration * target_rate)
        if timeline_frames < 1: raise ValueError(name + '：素材短於一個時間線影格。')
        metadata = clip.GetMetadata() or {}
        camera = str(metadata.get('Camera #') or metadata.get('Camera ID') or '').strip()
        folder = os.path.dirname(path)
        bin_info = bins.get(uid)
        if not bin_info: raise ValueError(name + '：找不到素材所屬 Bin，請重新選取素材。')
        source_folders[bin_info['folder'].GetUniqueId()] = bin_info['folder']
        group = 'camera:' + camera if camera else (bin_info['group'] or 'folder:' + folder)
        label = '機位 ' + camera if camera else (bin_info['label'] or os.path.basename(folder) or '自動分軌')
        clips.append({'item': clip, 'id': uid, 'name': name, 'tc': tc, 'start': frame, 'frames': timeline_frames, 'source_frames': int(raw_frames), 'source_rate': source_rate, 'source_start': source_start, 'source_duration': source_duration, 'props': props,
                      'group': group, 'label': label, 'camera': camera, 'bin_path': bin_info['path']})
    clips.sort(key=lambda c: (c['start'], c['id']))
    origin = clips[0]['start']
    end = origin
    day = nominal * 86400 - drop * 1296
    for clip in clips:
        end = max(end, clip['start'] + clip['frames'])
        if end > day: raise ValueError('素材跨過午夜，請先分段處理；本版不會猜測拍攝日期。')
    lanes = []
    for clip in clips:
        lane = next((lane for lane in lanes if lane['group'] == clip['group'] and lane['end'] <= clip['start']), None)
        if lane is None:
            lane = {'group': clip['group'], 'label': clip['label'], 'number': len(lanes) + 1, 'end': 0}
            lanes.append(lane)
        clip['lane'] = lane['number']
        lane['end'] = clip['start'] + clip['frames']
    if end - origin > nominal * 43200:
        raise ValueError('素材時間跨度超過 12 小時，可能跨日。請按拍攝時段分開選取。')
    result = {'project': project, 'pool': pool, 'clips': clips, 'start': origin, 'tc': frame_tc(origin, nominal, drop),
              'length': end - origin, 'format': shoot['format'], 'title': shoot.get('title') or 'SetMark', 'lanes': lanes, 'source_folders': list(source_folders.values())}
    signature = [project.GetUniqueId(), shoot, [(c['id'], c['props'], c['group'], c['label'], c['bin_path'], c['lane']) for c in clips]]
    result['fingerprint'] = hashlib.sha256(json.dumps(signature, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    result['preview'] = import_marks(resolve, file_path, timeline_override=SourcePreview(result))
    return result

class SourcePreview:
    def __init__(self, plan): self.plan = plan
    def GetSettings(self):
        _, rate, drop = FORMATS[self.plan['format']]
        return {'timelineFrameRate': str(rate), 'timelineDropFrameTimecode': str(int(bool(drop)))}
    def GetStartTimecode(self): return self.plan['tc']
    def GetStartFrame(self): return self.plan['start']
    def GetEndFrame(self): return self.plan['start'] + self.plan['length']
    def GetMarkers(self): return {}

def timeline_xml(plan, name):
    from fractions import Fraction
    from pathlib import Path
    import xml.etree.ElementTree as ET
    nominal, rate, drop = FORMATS[plan['format']]
    fractional = plan['format'].startswith(('23.976', '29.97', '59.94'))
    num, den = (nominal * 1000, 1001) if fractional else (nominal, 1)
    def seconds(frames):
        value = Fraction(frames * den, num)
        return str(value.numerator) + '/' + str(value.denominator) + 's'
    root = ET.Element('fcpxml', version='1.7')
    resources = ET.SubElement(root, 'resources')
    resolution = str(plan['clips'][0]['props'].get('Resolution', '1920x1080'))
    size = re.findall(r'\d+', resolution)
    width, height = size[:2] if len(size) >= 2 else ('1920', '1080')
    ET.SubElement(resources, 'format', id='r1', frameDuration=seconds(1), width=width, height=height)
    def rational_seconds(value):
        return str(value.numerator) + '/' + str(value.denominator) + 's'
    for index, clip in enumerate(plan['clips'], 2):
        fid = 'f' + str(index)
        clip_size = re.findall(r'\d+', str(clip['props'].get('Resolution', resolution)))
        cw, ch = clip_size[:2] if len(clip_size) >= 2 else (width,height)
        ET.SubElement(resources, 'format', id=fid, frameDuration=rational_seconds(1/clip['source_rate']), width=cw, height=ch)
        attributes = dict(id='r'+str(index), name=clip['name'], src=Path(clip['props']['File Path']).as_uri(),
            start=rational_seconds(clip['source_start']), duration=rational_seconds(clip['source_duration']), hasVideo='1', format=fid)
        audio = str(clip['props'].get('Audio Ch', '0'))
        if audio.isdigit() and int(audio) > 0: attributes.update(hasAudio='1', audioSources='1', audioChannels=audio)
        ET.SubElement(resources, 'asset', **attributes)
    library = ET.SubElement(root, 'library')
    event = ET.SubElement(library, 'event', name='SetMark')
    project = ET.SubElement(event, 'project', name=name)
    sequence = ET.SubElement(project, 'sequence', format='r1', duration=seconds(plan['length']),
        tcStart=seconds(plan['start']), tcFormat='DF' if drop else 'NDF')
    spine = ET.SubElement(sequence, 'spine')
    # Connected lanes over one full-length gap preserve independent cameras and stops.
    anchor = ET.SubElement(spine, 'gap', name='共用時間碼', offset=seconds(plan['start']), start='0s', duration=seconds(plan['length']))
    for index, clip in enumerate(plan['clips'], 2):
        ET.SubElement(anchor, 'asset-clip', ref='r'+str(index), name=clip['name'], offset=seconds(clip['start'] - plan['start']), lane=str(clip['lane']),
            start=rational_seconds(clip['source_start']), duration=seconds(clip['frames']), tcFormat='DF' if ';' in clip['tc'] else 'NDF')
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)

def build_and_import(resolve, file_path, expected):
    plan = source_plan(resolve, file_path)
    if plan['fingerprint'] != expected: raise ValueError('JSON、選取素材或專案已變更，請重新檢查。')
    project, pool = plan['project'], plan['pool']
    old = project.GetCurrentTimeline()
    from datetime import datetime
    name = 'SetMark_' + str(plan['title'])[:70] + '_' + datetime.now().strftime('%m%d_%H%M%S_%f')
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory(prefix='setmark-') as folder:
        xml = Path(folder) / 'timeline.fcpxml'
        xml.write_bytes(timeline_xml(plan, name))
        created = pool.ImportTimelineFromFile(str(xml), {'timelineName': name, 'importSourceClips': False, 'sourceClipsFolders': plan['source_folders']})
    if not created: raise ValueError('Resolve 無法依素材時間碼建立時間線。')
    try:
        if not project.SetCurrentTimeline(created): raise ValueError('無法切換至新時間線。')
        settings = created.GetSettings() if callable(getattr(created, 'GetSettings', None)) else created.GetSetting()
        nominal, rate, drop = FORMATS[plan['format']]
        fps = re.search(r'\d+(?:\.\d+)?', str(settings.get('timelineFrameRate', '')))
        if not fps or abs(float(fps.group()) - rate) > .01 or (str(settings.get('timelineDropFrameTimecode')).lower() in ('1', 'true')) != bool(drop):
            raise ValueError('新時間線的影格率或 DF／NDF 設定核對失敗。')
        if tc_frames(created.GetStartTimecode(), nominal, drop) != plan['start']: raise ValueError('新時間線起始時間碼核對失敗。')
        base = created.GetStartFrame()
        # Validate actual video placement and source offsets; the API may reject/ignore parameters.
        videos = []
        actual_tracks = {}
        for track in range(1, created.GetTrackCount('video') + 1):
            for item in created.GetItemListInTrack('video', track) or []:
                videos.append(item)
                actual_tracks[item.GetMediaPoolItem().GetUniqueId()] = track
        if len(videos) != len(plan['clips']): raise ValueError('新增的影片數量與選取素材不一致。')
        by_id = {v.GetMediaPoolItem().GetUniqueId(): v for v in videos}
        for clip in plan['clips']:
            item = by_id.get(clip['id'])
            target = base + clip['start'] - plan['start']
            if not item or item.GetStart() != target or item.GetDuration() != clip['frames'] or item.GetLeftOffset() != 0:
                raise ValueError('素材實際位置或長度核對失敗：' + clip['name'])
        lane_tracks = {}
        for clip in plan['clips']:
            lane_tracks.setdefault(clip['lane'], set()).add(actual_tracks[clip['id']])
        if any(len(tracks) != 1 for tracks in lane_tracks.values()) or len(set(next(iter(t)) for t in lane_tracks.values())) != len(lane_tracks):
            raise ValueError('多機素材分軌核對失敗。')
        for lane in plan['lanes']:
            created.SetTrackName('video', next(iter(lane_tracks[lane['number']])), 'SetMark ' + str(lane['number']) + ' · ' + lane['label'])
        audios = []
        for track in range(1, created.GetTrackCount('audio') + 1): audios.extend(created.GetItemListInTrack('audio', track) or [])
        for clip in plan['clips']:
            if str(clip['props'].get('Audio Ch', '0')).isdigit() and int(clip['props'].get('Audio Ch', '0')) > 0:
                audio = [a for a in audios if a.GetMediaPoolItem().GetUniqueId() == clip['id']]
                target = base + clip['start'] - plan['start']
                if not audio or any(a.GetStart() != target for a in audio):
                    raise ValueError('素材音訊未加入或位置不符：' + clip['name'])
        if created.GetEndFrame() - base != plan['length']: raise ValueError('時間線實際長度不符，已停止匯入。')
        result = import_marks(resolve, file_path, apply=True)
        result['timeline_name'] = created.GetName()
        result['video_lanes'] = len(plan['lanes'])
        return result
    except Exception as exc:
        # Only remove the new timeline owned by this operation, never the user's existing one.
        removed = False
        try:
            if old: project.SetCurrentTimeline(old)
            removed = pool.DeleteTimelines([created])
        except Exception: pass
        message = '建立未完成：' + str(exc)
        if not removed: message += '\n未能自動移除本次新建時間線：' + name + '。請勿使用它，確認後可刪除。'
        raise ValueError(message) from exc


def launch(resolve, fusion, bmd):
    import hashlib
    from pathlib import Path
    ui = fusion.UIManager
    dispatcher = bmd.UIDispatcher(ui)
    win = dispatcher.AddWindow({'ID': 'SetMarkImport', 'WindowTitle': 'SetMark · 匯入 JSON 標記', 'Geometry': [180, 180, 760, 600]}, ui.VGroup([
        ui.Label({'Text': '建立素材時間碼時間線，或將 JSON 標記匯入目前時間線。', 'Weight': 0}),
        ui.HGroup({'Weight': 0}, [ui.LineEdit({'ID': 'Path', 'PlaceholderText': '選擇 SetMark JSON，或貼上完整路徑'}), ui.Button({'ID': 'Browse', 'Text': '選擇 JSON'})]),
        ui.CheckBox({'ID': 'NewTimeline', 'Text': '依媒體池選取素材建立新時間線，並匯入 JSON', 'Checked': False, 'Weight': 0}),
        ui.Label({'Text': '建立新時間線：先在媒體池選取各機影片；依 Camera #、媒體池 Bin 或來源資料夾分軌，重疊素材自動拆軌。', 'WordWrap': True, 'Weight': 0}),
        ui.CheckBox({'ID': 'Aligned', 'Text': '我已確認：時間線時間碼與素材來源時間碼對齊', 'Checked': False, 'Weight': 0}),
        ui.TextEdit({'ID': 'Report', 'ReadOnly': True, 'AcceptRichText': False, 'PlainText': '選擇檔案後按「檢查標記」。'}),
        ui.HGroup({'Weight': 0}, [ui.Button({'ID': 'Preview', 'Text': '檢查標記'}), ui.Button({'ID': 'Apply', 'Text': '匯入標記', 'Enabled': False}), ui.Button({'ID': 'Close', 'Text': '關閉'})])
    ]))
    items = win.GetItems()
    state = {}
    def timeline():
        project = resolve.GetProjectManager().GetCurrentProject()
        t = project.GetCurrentTimeline() if project else None
        if not t: raise ValueError('請先開啟需要加入標記的時間線。')
        return t
    def fingerprint(path):
        t = timeline()
        return (str(path), hashlib.sha256(path.read_bytes()).hexdigest(), t.GetUniqueId(), t.GetStartTimecode(), t.GetEndFrame(), repr(t.GetMarkers()), repr((t.GetSettings() if callable(getattr(t, 'GetSettings', None)) else t.GetSetting())))
    def invalidate(ev=None):
        state.clear(); items['Apply'].Enabled = False
    def report(result):
        return ('可新增：%d 個位置\n已匯入：%d\n同位置衝突：%d\n時間線範圍外：%d\n' % (result['planned'], result['already_present'], len(result['conflicts']), len(result['out_of_range'])))
    def browse(ev):
        try:
            chosen = fusion.RequestFile()
            if chosen: items['Path'].Text = chosen; invalidate()
        except Exception as exc: items['Report'].PlainText = '無法開啟選檔視窗，請貼上 JSON 完整路徑。\n' + str(exc)
    def preview(ev):
        invalidate()
        try:
            path = Path(items['Path'].Text.strip()).expanduser()
            data = read_shoot(path)
            new = bool(items['NewTimeline'].Checked)
            if new:
                plan = source_plan(resolve, path)
                result = plan['preview']
                heading = '將建立新時間線；起始：' + plan['tc'] + '\n素材：' + str(len(plan['clips'])) + ' 個，影片軌道：' + str(len(plan['lanes'])) + ' 軌（保留停機空隙）' + '\n' + '\n'.join('軌 ' + str(lane['number']) + '：' + lane['label'] for lane in plan['lanes'])
                stamp = plan['fingerprint']
            else:
                result = import_marks(resolve, path)
                heading = '時間線：' + timeline().GetName()
                stamp = fingerprint(path)
            items['Report'].PlainText = (heading + '\n專案：' + data.get('title', '') + '\n格式：' + data['format'] + '\n已補回每個標記各自的往前保留時間，匯入點為按下按鈕的時間。\n\n' + report(result) + '\n' + '\n'.join((m.get('author') or '') + ' · ' + m['tag'] + ('：' + m.get('note', '') if m.get('note') else '') for m in data['marks'][:100]) + '\n\n範圍外的點會略過；衝突位置不會覆蓋。')
            state.update(path=path, fingerprint=stamp, new=new, planned=result['planned'])
            items['Apply'].Enabled = bool(new or (items['Aligned'].Checked and result['planned']))
        except Exception as exc: items['Report'].PlainText = '尚未匯入：' + str(exc)
    def apply(ev):
        try:
            if not state or (not state.get('new') and not items['Aligned'].Checked): raise ValueError('請先確認對齊並重新檢查。')
            path = state['path']
            items['Apply'].Enabled = False
            if state['new']:
                result = build_and_import(resolve, path, state['fingerprint'])
                items['NewTimeline'].Checked = False
                items['Aligned'].Checked = True
                items['Aligned'].Enabled = True
                items['Apply'].Text = '匯入標記'
            else:
                if fingerprint(path) != state['fingerprint']: raise ValueError('檔案或時間線已變更，請重新檢查。')
                result = import_marks(resolve, path, apply=True)
            items['Report'].PlainText = ('已建立時間線：' + result['timeline_name'] + '\n' if 'timeline_name' in result else '') + '已新增 %d 個標記。\n失敗：%d\n\n%s\n請儲存 Resolve 專案。' % (result['added'],len(result['failed']),report(result))
            state.clear()
        except Exception as exc:
            invalidate(); items['Report'].PlainText = '匯入未完成：' + str(exc) + '\n可重新檢查；已成功加入的點不會重複加入。'
    win.On.Browse.Clicked = browse
    win.On.Preview.Clicked = preview
    win.On.Apply.Clicked = apply
    win.On.Path.TextChanged = invalidate
    def mode_changed(ev):
        invalidate()
        new = bool(items['NewTimeline'].Checked)
        items['Aligned'].Enabled = not new
        items['Apply'].Text = '建立時間線並匯入' if new else '匯入標記'
        items['Report'].PlainText = '請重新按「檢查標記」。'
    def alignment_changed(ev):
        items['Apply'].Enabled = bool(state and (state.get('new') or (items['Aligned'].Checked and state.get('planned'))))
    win.On.NewTimeline.Clicked = mode_changed
    win.On.Aligned.Clicked = alignment_changed
    win.On.Close.Clicked = lambda ev: dispatcher.ExitLoop()
    win.On.SetMarkImport.Close = lambda ev: dispatcher.ExitLoop()
    win.Show()
    dispatcher.RunLoop()
    win.Hide()

if 'resolve' in globals() and 'fusion' in globals() and 'bmd' in globals():
    launch(resolve, fusion, bmd)
