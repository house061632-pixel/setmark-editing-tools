from pathlib import Path
import py_compile
root = Path(__file__).resolve().parent
source = root.parent / 'SetMark' / 'Resolve'
target = root / 'SetMark Import JSON.py'
target.write_text('\n\n'.join((source/name).read_text(encoding='utf-8') for name in ['import_markers.py','build_timeline.py','ui_import.py']), encoding='utf-8')
compile(target.read_text(encoding='utf-8'), str(target), 'exec')
print('Resolve script generated and syntax verified.')
