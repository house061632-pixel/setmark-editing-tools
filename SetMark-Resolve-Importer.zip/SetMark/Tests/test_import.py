import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
spec = importlib.util.spec_from_file_location('importer', Path(__file__).parents[1] / 'Resolve/import_markers.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class Timeline:
    def __init__(self): self.markers = {}; self.fps = '29.97'; self.df = '0'
    def GetSettings(self): return {'timelineFrameRate': self.fps, 'timelineDropFrameTimecode': self.df}
    def GetStartTimecode(self): return '15:00:00:00'
    def GetStartFrame(self): return 1620000
    def GetEndFrame(self): return 1620300
    def GetMarkers(self): return self.markers
    def AddMarker(self, frame, color, name, note, duration, custom):
        self.markers[frame] = {'customData': custom, 'name': name}; return True
class Resolve:
    def __init__(self): self.timeline = Timeline()
    def GetProjectManager(self): return self
    def GetCurrentProject(self): return self
    def GetCurrentTimeline(self): return self.timeline
class Tests(unittest.TestCase):
    def test_per_mark_lookback(self):
        resolve = Resolve()
        shoot = {'id':'mixed', 'format':'29.97 NDF', 'lookback': 25, 'marks':[
            {'id':'a','frame':1619900,'tag':'爆笑','lookbackFrames':150},
            {'id':'b','frame':1619990,'tag':'金句','lookbackFrames':90},
            {'id':'c','frame':1620100,'tag':'NG','lookbackFrames':0}]}
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'marks.json'; path.write_text(json.dumps(shoot))
            self.assertEqual(module.import_marks(resolve,path,True)['added'],3)
            self.assertEqual(set(resolve.timeline.markers),{50,80,100})
            self.assertEqual(module.import_marks(resolve,path,True)['already_present'],3)
    def test_import(self):
        resolve = Resolve()
        shoot = {'id':'project', 'format':'29.97 NDF', 'marks':[
            {'id':'a','frame':1620030,'tag':'爆笑'}, {'id':'b','frame':1620030,'tag':'金句'},
            {'id':'c','frame':100,'tag':'NG'}], 'lookback': 1}
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'marks.json'; path.write_text(json.dumps(shoot))
            shoot['isTest']=True; path.write_text(json.dumps(shoot))
            with self.assertRaises(ValueError): module.import_marks(resolve,path,True)
            self.assertEqual(resolve.timeline.markers,{})
            shoot.pop('isTest'); path.write_text(json.dumps(shoot))
            result=module.import_marks(resolve,path)
            self.assertEqual(result['planned'],1); self.assertEqual(resolve.timeline.markers,{})
            self.assertEqual(result['out_of_range'],['c'])
            self.assertEqual(module.import_marks(resolve,path,True)['added'],1)
            self.assertIn(60,resolve.timeline.markers)
            self.assertEqual(module.import_marks(resolve,path,True)['already_present'],1)
            resolve.timeline.markers[60]={'customData':'other'}
            self.assertEqual(module.import_marks(resolve,path,True)['conflicts'],[60])
            resolve.timeline.fps='24'
            with self.assertRaises(ValueError): module.import_marks(resolve,path,True)
            resolve.timeline.fps='29.97'; resolve.timeline.df='1'
            with self.assertRaises(ValueError): module.import_marks(resolve,path,True)
if __name__ == '__main__': unittest.main()

class BatchTests(unittest.TestCase):
    def test_batch_origins_append_and_legacy(self):
        r = Resolve()
        def add(frame,color,name,note,duration,custom):
            if frame in r.timeline.markers: return False
            r.timeline.markers[frame] = dict(color=color,name=name,note=note,duration=duration,customData=custom)
            return True
        r.timeline.AddMarker = add
        def delete(frame):
            return r.timeline.markers.pop(frame, None) is not None
        r.timeline.DeleteMarkerAtFrame = delete
        with tempfile.TemporaryDirectory() as folder:
            def write(project, offset):
                p=Path(folder)/(project+'.json')
                p.write_text(json.dumps(dict(id=project,title=project,format='29.97 NDF',marks=[dict(id='same',frame=1620030,tag='開機',note='場次 2 鏡號 3 Take 4',lookbackFrames=offset)])))
                return p
            a,b,c=write('A',0),write('B',0),write('C',10)
            first=module.import_marks(r,[a,b],True)
            self.assertEqual(first['added'],1)
            self.assertIn('【A】',r.timeline.markers[30]['note']);self.assertIn('【B】',r.timeline.markers[30]['note'])
            self.assertEqual(module.import_marks(r,[b,a])['planned'],0)
            self.assertEqual(module.import_marks(r,a)['planned'],0)
            self.assertEqual(module.import_marks(r,[a,c],True)['added'],1)
            d=write('D',0)
            r.timeline.markers[30]['note'] += '\n剪輯師備註'
            self.assertEqual(module.import_marks(r,d,True)['updated'],1)
            self.assertIn('剪輯師備註',r.timeline.markers[30]['note'])
            self.assertIn('【D】',r.timeline.markers[30]['note'])
            self.assertEqual(module.import_marks(r,[a,b,c,d])['planned'],0)
            r.timeline.markers[30]['customData']='setmark:v2:A:same'
            self.assertEqual(module.import_marks(r,[a,c])['planned'],0)
    def test_batch_validation_no_mutations(self):
        r=Resolve()
        with tempfile.TemporaryDirectory() as folder:
            a,b=Path(folder)/'a.json',Path(folder)/'b.json'
            data=dict(id='A',format='29.97 NDF',marks=[dict(id='m',frame=1620030,tag='NG')])
            a.write_text(json.dumps(data));b.write_text(json.dumps(dict(data,format='29.97 DF')))
            with self.assertRaisesRegex(ValueError,'格式必須一致'): module.import_marks(r,[a,b],True)
            data['marks'][0]['frame']+=1;b.write_text(json.dumps(data))
            with self.assertRaisesRegex(ValueError,'不同版本'): module.import_marks(r,[a,b],True)
            b.write_text('bad')
            with self.assertRaises(ValueError): module.import_marks(r,[a,b],True)
            self.assertEqual(r.timeline.markers,{})
            self.assertEqual(len(module.read_shoot([a,a])['marks']),1)
    def test_restore_existing_marker_when_append_fails(self):
        r=Resolve();old=dict(customData='setmark:v2:A:a',name='original',note='keep',color='Green',duration=3)
        r.timeline.markers[30]=old.copy()
        def delete(frame): del r.timeline.markers[frame];return True
        def add(frame,color,name,note,duration,custom):
            if custom != old['customData']: return False
            r.timeline.markers[frame]=dict(customData=custom,name=name,note=note,color=color,duration=duration);return True
        r.timeline.DeleteMarkerAtFrame=delete;r.timeline.AddMarker=add
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'b.json';path.write_text(json.dumps(dict(id='B',format='29.97 NDF',marks=[dict(id='b',frame=1620030,tag='NG')])))
            result=module.import_marks(r,path,True)
            self.assertEqual(result['failed'],[30]);self.assertEqual(r.timeline.markers[30],old)
