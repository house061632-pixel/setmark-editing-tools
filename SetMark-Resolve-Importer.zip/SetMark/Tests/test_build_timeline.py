import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).parents[1] / 'Resolve'
api = {}
exec(compile((ROOT/'import_markers.py').read_text(), 'import_markers.py', 'exec'), api)
exec(compile((ROOT/'build_timeline.py').read_text(), 'build_timeline.py', 'exec'), api)

class Clip:
    def __init__(self, uid, path, tc, frames=90):
        self.uid = uid
        self.props = {'File Path': str(path), 'Start TC': tc, 'FPS': '29.97', 'Frames': str(frames), 'Audio Ch': '2', 'Type': 'Video + Audio'}
    def GetMetadata(self): return getattr(self, "metadata", {})
    def GetName(self): return self.uid
    def GetUniqueId(self): return self.uid
    def GetClipProperty(self): return self.props.copy()

class Item:
    def __init__(self, info, wrong): self.info = info; self.wrong = wrong
    def GetMediaPoolItem(self): return self.info['mediaPoolItem']
    def GetStart(self): return self.info['recordFrame'] + int(self.wrong)
    def GetDuration(self): return self.info['endFrame'] - self.info['startFrame'] + 1
    def GetLeftOffset(self): return self.info['startFrame']

class Timeline:
    def __init__(self, name):
        self.name=name; self.items=[]; self.markers={}; self.tc='01:00:00;00'; self.settings={}; self.audio=True
    def GetName(self): return self.name
    def SetName(self, name): self.name=name; return True
    def GetUniqueId(self): return self.name
    def SetSettings(self, settings):
        self.settings.update(settings)
        if 'timelineFrameRate' in settings: self.settings['timelineDropFrameTimecode']='1' if 'DF' in settings['timelineFrameRate'] else '0'
        return True
    def GetSettings(self): return self.settings
    def SetStartTimecode(self, tc): self.tc=tc; return True
    def GetStartTimecode(self): return self.tc
    def GetStartFrame(self): return api['tc_frames'](self.tc,30,2)
    def GetEndFrame(self): return max([i.GetStart()+i.GetDuration() for i in self.items] or [self.GetStartFrame()])
    def GetTrackCount(self, kind): return max([i.info.get('lane',1) for i in self.items if i.info.get('kind')==kind] or [0])
    def SetTrackName(self, *args): return True
    def GetItemListInTrack(self, kind, track): return [i for i in self.items if i.info.get('lane',1)==track and i.info.get('kind')==kind] if kind=='video' or self.audio else []
    def GetMarkers(self): return self.markers
    def AddMarker(self, frame, color, name, note, duration, custom):
        self.markers[frame]={'customData':custom}; return True

class Folder:
    def __init__(self, uid, name, clips=None, children=None):
        self.uid=uid; self.name=name; self.clips=clips or []; self.children=children or []
    def GetUniqueId(self): return self.uid
    def GetName(self): return self.name
    def GetClipList(self): return self.clips
    def GetSubFolderList(self): return self.children

class Resolve:
    def __init__(self, clips):
        self.clips=clips; self.old=Timeline('original'); self.current=self.old; self.created=[]; self.wrong=False; self.fail=False; self.audio=True
    def GetProjectManager(self): return self
    def GetCurrentProject(self): return self
    def GetMediaPool(self): return self
    def GetRootFolder(self): return getattr(self, 'root', Folder('root','Master',self.clips))
    def GetCurrentFolder(self): return getattr(self,'current_folder',self.GetRootFolder())
    def GetUniqueId(self): return 'project'
    def GetCurrentTimeline(self): return self.current
    def SetCurrentTimeline(self, t): self.current=t; return True
    def GetSelectedClips(self): return self.clips
    def CreateEmptyTimeline(self, name):
        t=Timeline(name); t.audio=self.audio; self.created.append(t); return t
    def AppendToTimeline(self, infos):
        if self.fail: return []
        items=[Item(i,self.wrong) for i in infos]; self.current.items.extend(items); return items
    def ImportTimelineFromFile(self, path, options):
        if self.fail: return None
        import xml.etree.ElementTree as ET
        from fractions import Fraction
        root=ET.parse(path).getroot()
        seq=root.find('./library/event/project/sequence')
        duration=Fraction(root.find('./resources/format').get('frameDuration')[:-1])
        def frames(value): return int(Fraction(value[:-1])/duration)
        t=self.CreateEmptyTimeline(options['timelineName']); t.tc=api['frame_tc'](frames(seq.get('tcStart')),30,2)
        t.settings={'timelineFrameRate':'29.97','timelineDropFrameTimecode':'1'}
        names={c.uid:c for c in self.clips}
        for node in seq.findall('./spine/gap/clip'):
            info={'mediaPoolItem':names[node.get('name')], 'startFrame':0,
                'endFrame':frames(node.get('duration'))-1, 'recordFrame':frames(node.get('offset'))+frames(seq.get('tcStart')), 'lane':abs(int(node.get('lane'))), 'kind':list(node)[0].tag}
            if info['kind']=='audio' and getattr(self,'split_audio',False): info['lane']=len(t.items)+1
            t.items.append(Item(info,self.wrong))
        return t
    def DeleteTimelines(self, timelines):
        for t in timelines: self.created.remove(t)
        return True

class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        root=Path(self.temp.name); media=root/'camera.mp4'; media.touch()
        self.clips=[Clip('later',media,'02:00:10;00'), Clip('first',media,'02:00:00;00')]
        self.r=Resolve(self.clips); self.path=root/'marks.json'
        self.shoot={'id':'s','title':'demo','format':'29.97 DF','lookback':5,'marks':[
            {'id':'a','frame':215784-100,'lookbackFrames':150,'tag':'爆笑'},
            {'id':'b','frame':215784+310,'lookbackFrames':0,'tag':'金句'}]}
        self.write()
    def write(self): self.path.write_text(json.dumps(self.shoot))
    def test_multiple_json_create_one_timeline_and_append_without_new_timeline(self):
        second = self.path.parent/'second.json'
        second.write_text(json.dumps(dict(id='second',title='second',format='29.97 DF',marks=[dict(id='c',frame=215884,tag='NG')])))
        files=[self.path,second]
        plan=api['source_plan'](self.r,files)
        self.assertEqual(plan['preview']['planned'],3)
        result=api['build_and_import'](self.r,files,plan['fingerprint'])
        self.assertEqual(result['added'],3);self.assertEqual(len(self.r.created),1)
        self.assertEqual(api['import_marks'](self.r,files)['planned'],0)
        third=self.path.parent/'third.json'
        third.write_text(json.dumps(dict(id='third',format='29.97 DF',marks=[dict(id='d',frame=215984,tag='開機')])))
        self.assertEqual(api['import_marks'](self.r,[third],True)['added'],1)
        self.assertEqual(len(self.r.created),1)

    def test_create_origin_gaps_audio_and_marks(self):
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(plan['tc'],'02:00:00;00'); self.assertEqual(plan['preview']['planned'],2)
        self.assertEqual(self.r.created,[])
        result=api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(result['added'],2); self.assertEqual(self.r.current.GetStartTimecode(),'02:00:00;00')
        self.assertEqual([i.GetStart()-self.r.current.GetStartFrame() for i in self.r.current.items if i.info['kind']=='video'],[0,300])
        self.assertEqual(set(self.r.current.markers),{50,310}); self.assertEqual(self.r.old.items,[])
    def test_changed_selection_or_json_stops_before_create(self):
        plan=api['source_plan'](self.r,self.path)
        self.r.clips=self.clips[:1]
        with self.assertRaisesRegex(ValueError,'已變更'): api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(self.r.created,[])
        self.r.clips=self.clips; self.shoot['marks'][0]['lookbackFrames']=90; self.write()
        with self.assertRaisesRegex(ValueError,'已變更'): api['build_and_import'](self.r,self.path,plan['fingerprint'])
    def test_wrong_native_placement_preserves_diagnostic_timeline(self):
        plan=api['source_plan'](self.r,self.path); self.r.wrong=True
        with self.assertRaisesRegex(ValueError,'核對失敗'): api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(len(self.r.created),1); self.assertTrue(self.r.current.GetName().startswith("未驗證_勿剪輯_"))
    def test_missing_audio_preserves_diagnostic_timeline(self):
        plan=api['source_plan'](self.r,self.path); self.r.audio=False
        with self.assertRaisesRegex(ValueError,'音訊'): api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(len(self.r.created),1)
    def test_timeline_import_failure_preserves_existing(self):
        plan=api['source_plan'](self.r,self.path); self.r.fail=True
        with self.assertRaisesRegex(ValueError,'無法依素材時間碼'): api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertIs(self.r.current,self.r.old); self.assertEqual(self.r.created,[])
    def test_preflight_rejects_ambiguous_or_invalid_sources(self):
        for prop,value in [('FPS','24'),('File Path','/not-mounted/a.mp4'),('Start TC','02:00:10:00')]:
            old=self.clips[0].props[prop]; self.clips[0].props[prop]=value
            with self.assertRaises(ValueError): api['source_plan'](self.r,self.path)
            self.clips[0].props[prop]=old
        self.shoot['marks'][0]['lookbackFrames']=-1; self.write()
        with self.assertRaises(ValueError): api['source_plan'](self.r,self.path)
        self.assertEqual(self.r.created,[])

    def test_bins_separate_nonoverlapping_clips_in_same_disk_folder(self):
        a,b=self.clips
        self.r.root=Folder('root','Master',children=[Folder('a','A機',[a]),Folder('b','B機',[b])])
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['lanes']),2)
        self.assertEqual({c['label'] for c in plan['clips']},{'A機','B機'})
        self.assertEqual({f.GetUniqueId() for f in plan['source_folders']},{'a','b'})
        api['build_and_import'](self.r,self.path,plan['fingerprint'])

    def test_cards_share_camera_ancestor_and_metadata_overrides_bin(self):
        a,b=self.clips
        self.r.root=Folder('root','Master',children=[Folder('a','A機',children=[Folder('card1','卡1',[a]),Folder('card2','卡2',[b])])])
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['lanes']),1)
        a.metadata={'Camera #':'B'}
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['lanes']),2)
        self.assertIn('機位 B',{c['label'] for c in plan['clips']})

    def test_same_name_bins_distinct_and_bin_changes_require_new_preview(self):
        a,b=self.clips
        fa,fb=Folder('a','A機',[a]),Folder('b','A機',[b])
        self.r.root=Folder('root','Master',children=[fa,fb])
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['lanes']),2)
        fa.name='B機'
        with self.assertRaisesRegex(ValueError,'已變更'): api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(self.r.created,[])

    def test_eight_cameras_share_timeline_and_stay_on_separate_tracks(self):
        media=self.clips[0].props['File Path']
        self.r.clips=[Clip('cam'+str(i),media,'02:00:00;00',90) for i in range(8)]
        for i,c in enumerate(self.r.clips): c.metadata={'Camera #':str(i+1)}
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['lanes']),8)
        result=api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(result['video_lanes'],8)
        self.assertEqual(self.r.current.GetTrackCount('video'),8)
        self.assertEqual({i.GetStart() for i in self.r.current.items},{215784})
    def test_camera_restarts_reuse_track_and_overlaps_split(self):
        media=self.clips[0].props['File Path']
        a=Clip('a',media,'02:00:00;00');b=Clip('b',media,'02:00:10;00');c=Clip('c',media,'02:00:00;00')
        a.metadata=b.metadata={'Camera #':'A'};c.metadata={'Camera #':'B'}
        self.r.clips=[a,b,c]
        plan=api['source_plan'](self.r,self.path)
        lanes={x['id']:x['lane'] for x in plan['clips']}
        self.assertEqual(lanes['a'],lanes['b']);self.assertNotEqual(lanes['a'],lanes['c'])
        c.metadata={'Camera #':'A'}
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['lanes']),2)

    def test_mixed_5994_preserves_seconds_and_source_format(self):
        import xml.etree.ElementTree as ET
        from fractions import Fraction
        c=self.clips[1]; c.props.update(FPS='59.94', Frames='180', **{'Start TC':'02:00:00;00'})
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(plan['clips'][0]['frames'],90)
        root=ET.fromstring(api['timeline_xml'](plan,'mixed'))
        asset=root.find('./resources/asset')
        fmt=next(x for x in root.findall('./resources/format') if x.get('id')==asset.get('format'))
        self.assertEqual(Fraction(fmt.get('frameDuration')[:-1]),Fraction(1001,60000))
        self.assertEqual(Fraction(asset.get('duration')[:-1]),Fraction(3003,1000))
        api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(self.r.current.items[0].GetDuration(),90)

    def test_5994_half_frame_start_and_odd_duration(self):
        c=self.clips[1]; c.props.update(FPS='59.94', Frames='181', **{'Start TC':'02:00:00;31'})
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(plan['start'],215800)
        self.assertEqual(plan['tc'],'02:00:00;16')
        self.assertEqual(plan['clips'][0]['frames'],91)
        api['build_and_import'](self.r,self.path,plan['fingerprint'])

    def test_integer_rate_mix_preserves_real_duration(self):
        c=self.clips[0]; c.props.update(FPS='24', Frames='72', **{'Start TC':'02:00:10:00'})
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(next(c for c in plan['clips'] if c['id']=='later')['frames'],90)
        api['build_and_import'](self.r,self.path,plan['fingerprint'])

    def test_round_trip_df_boundaries_and_all_supported_rates(self):
        for nominal,drop in [(30,2),(60,4),(24,0)]:
            for frame in [0,1,1799,1800,17982,107892,215784]:
                self.assertEqual(api['tc_frames'](api['frame_tc'](frame,nominal,drop),nominal,drop),frame)
        for rate in ['23.976','24','25','29.97','30','50','59.94','60']:
            self.assertGreater(api['media_rate'](rate),0)
        with self.assertRaises(ValueError): api['media_rate']('27')

    def test_current_bin_recurses_cards_and_excludes_siblings(self):
        a,b=self.clips
        a.metadata={'Camera #':'A'}; b.metadata={'Camera #':'B'}
        video=Folder('video','video',children=[Folder('a','A機',children=[Folder('card1','A001',[a])]),Folder('b','B機',children=[Folder('card2','A002',[b])])])
        other=Clip('outside',a.props['File Path'],'02:00:00;00')
        self.r.root=Folder('root','Master',children=[video,Folder('outside','Other',[other])]);self.r.current_folder=video
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual({c['id'] for c in plan['clips']},{a.uid,b.uid})
        self.assertEqual(len(plan['lanes']),2)
        api['build_and_import'](self.r,self.path,plan['fingerprint'])

    def test_bin_change_and_child_addition_invalidates_preview(self):
        folder=Folder('video','video',self.clips.copy());self.r.root=folder
        plan=api['source_plan'](self.r,self.path)
        folder.clips.append(Clip('new',self.clips[0].props['File Path'],'02:00:00;00'))
        with self.assertRaisesRegex(ValueError,'已變更'): api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(self.r.created,[])

    def test_nonvideo_skipped_empty_and_offline_fail(self):
        self.clips[0].props['Type']='Still'
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['clips']),1);self.assertEqual(len(plan['skipped']),1)
        self.clips[1].props['Type']='Audio'
        with self.assertRaisesRegex(ValueError,'沒有可同步'): api['source_plan'](self.r,self.path)
        self.clips[1].props['Type']='Video';self.clips[1].props['File Path']='/missing'
        with self.assertRaisesRegex(ValueError,'離線'): api['source_plan'](self.r,self.path)

    def test_audio_reuse_same_camera_across_cards(self):
        a,b=self.clips
        self.r.root=Folder('root','Master',children=[Folder('cam','Acam',children=[Folder('card1','A001',[a]),Folder('card2','A002',[b])])])
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['audio_lanes']),1)
        api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(self.r.current.GetTrackCount('audio'),1)
        self.assertEqual(len(self.r.current.GetItemListInTrack('audio',1)),2)

    def test_audio_overlap_and_channel_change_split_blocks(self):
        self.clips[0].props['Start TC']=self.clips[1].props['Start TC']
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['audio_lanes']),2)
        api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.clips[0].props['Start TC']='02:00:10;00'
        self.clips[0].props['Audio Ch']='4'
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['audio_lanes']),2)

    def test_importer_ignoring_audio_reuse_preserves_diagnostic_timeline(self):
        plan=api['source_plan'](self.r,self.path);self.r.split_audio=True
        with self.assertRaisesRegex(ValueError,'未重用'):api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(len(self.r.created),1);self.assertTrue(self.r.current.GetName().startswith("未驗證_勿剪輯_"))

    def test_500_segments_share_one_audio_lane(self):
        media=self.clips[0].props['File Path']
        self.r.clips=[Clip(str(i),media,api['frame_tc'](215784+i*100,30,2)) for i in range(500)]
        plan=api['source_plan'](self.r,self.path)
        self.assertEqual(len(plan['audio_lanes']),1)
        api['build_and_import'](self.r,self.path,plan['fingerprint'])
        self.assertEqual(len(self.r.current.GetItemListInTrack('audio',1)),500)


class CardDockTests(unittest.TestCase):
    def test_top_down_order_and_metadata_exclusion(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);v=root/'a.mp4';v.touch()
            clips=[Clip('pa',v,'01:00:00;00'),Clip('b',v,'01:00:01;00'),Clip('a',v,'01:00:02;00')]
            r=Resolve(clips)
            r.root=Folder('root','Master',children=[Folder('pa','PA',[clips[0]]),Folder('b','Bcam',[clips[1]]),Folder('a','Acam',children=[Folder('card','A001',[clips[2]])]),Folder('meta','_CARD_METADATA',[Clip('thumb',v,'01:00:00;00')])])
            j=root/'s.json';j.write_text(json.dumps(dict(id='s',format='29.97 DF',marks=[])))
            plan=api['source_plan'](r,j)
            self.assertEqual({c['id']:c['lane'] for c in plan['clips']},{'a':3,'b':2,'pa':1})

class LTCTests(unittest.TestCase):
    def test_audio_manifest_generates_negative_lane_and_checks_hash(self):
        import wave,hashlib,xml.etree.ElementTree as ET
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder); wav=root/'mic.wav'
            with wave.open(str(wav),'wb') as w:
                w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000);w.writeframes(b'\x00\x00'*48000)
            clip=Clip('mic',wav,'00:00:00;00');clip.props.update(Type='Audio', **{'Audio Ch':'1'})
            r=Resolve([clip]);shoot=root/'shoot.json'
            entry=dict(path=str(wav),startTicks=str(3600*254016000000),sampleRate=48000,sampleFrames=48000,channels=1,sha256=hashlib.sha256(wav.read_bytes()).hexdigest())
            data=dict(id='s',format='29.97 DF',marks=[],ltcAudio=dict(version=1,format='29.97 DF',clips=[entry]))
            shoot.write_text(json.dumps(data));plan=api['source_plan'](r,shoot)
            self.assertTrue(plan['clips'][0]['audio_only'])
            xml=ET.fromstring(api['timeline_xml'](plan,'LTC'))
            self.assertEqual(xml.find('./resources/asset').get('hasVideo'),'0')
            self.assertLess(int(xml.find('.//spine/gap/clip').get('lane')),0)
            wav.write_bytes(wav.read_bytes()+b'changed')
            with self.assertRaisesRegex(ValueError,'已變更'):api['source_plan'](r,shoot)
    def test_missing_ltc_copy_fails_before_build(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);v=root/'a.mp4';v.touch();r=Resolve([Clip('a',v,'01:00:00;00')]);j=root/'s.json'
            j.write_text(json.dumps(dict(id='s',format='29.97 DF',marks=[],ltcAudio=dict(version=1,format='29.97 DF',clips=[dict(path=str(root/'missing.wav'))]))))
            with self.assertRaisesRegex(ValueError,'全部 LTC'):api['source_plan'](r,j)

if __name__=='__main__': unittest.main()
