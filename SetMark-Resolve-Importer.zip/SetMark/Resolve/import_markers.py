"""Run in Resolve's Python console after setting FILE to an exported SetMark JSON.
Requires a timeline laid out against the same source timecode, with matching FPS/DF.
No clips are moved. Existing markers are never overwritten.
"""
import json
import re
from collections import defaultdict

FORMATS = {
    '23.976': (24, 24000/1001, 0), '24': (24, 24, 0), '25': (25, 25, 0),
    '29.97 NDF': (30, 30000/1001, 0), '29.97 DF': (30, 30000/1001, 2),
    '30': (30, 30, 0), '50': (50, 50, 0),
    '59.94 NDF': (60, 60000/1001, 0), '59.94 DF': (60, 60000/1001, 4), '60': (60, 60, 0)
}

def tc_frames(tc, nominal, drop):
    values = list(map(int, re.findall(r'\d+', tc)))
    if len(values) != 4:
        raise ValueError('無法讀取時間軸起始時間碼')
    h, m, s, f = values
    if h >= 24 or m >= 60 or s >= 60 or f >= nominal or (drop and m % 10 and s == 0 and f < drop):
        raise ValueError('時間碼不符合專案格式')
    minutes = h * 60 + m
    return ((h * 3600 + m * 60 + s) * nominal + f) - drop * (minutes - minutes // 10)

def read_shoot(file_path):
    if isinstance(file_path, (list, tuple)):
        if not 1 <= len(file_path) <= 100: raise ValueError('請選擇 1～100 個 JSON')
        from pathlib import Path
        if sum(Path(p).stat().st_size for p in file_path) > 20 * 1024 * 1024:
            raise ValueError('所選 JSON 合計超過 20 MB，請分批匯入')
        sources = [read_shoot(p) for p in file_path]
        if any(s['format'] != sources[0]['format'] for s in sources):
            raise ValueError('多個 JSON 的時間碼格式必須一致，包括 DF／NDF')
        unique, audio = {}, {}
        rate = FORMATS[sources[0]['format']][1]
        for source in sources:
            for mark in source['marks']:
                value = dict(mark, projectID=source['id'], projectTitle=source.get('title', '未命名專案'),
                             lookbackFrames=mark.get('lookbackFrames', int(round(source.get('lookback', 0) * rate))))
                key = (source['id'], mark['id'])
                if key in unique and unique[key] != value:
                    raise ValueError('同一標記有不同版本，請只選最新 JSON：' + source.get('title', source['id']))
                unique[key] = value
            ltc = source.get('ltcAudio')
            if ltc:
                if ltc.get('version') != 1 or ltc.get('format') != source['format'] or not isinstance(ltc.get('clips'), list):
                    raise ValueError('LTC 同步資料版本／格式不符')
                local = set()
                for entry in ltc['clips']:
                    key = str(Path(entry['path']).resolve())
                    if key in local: raise ValueError('LTC 音訊清單重複')
                    local.add(key)
                    if key in audio and audio[key] != entry: raise ValueError('LTC 音訊有不同版本：' + key)
                    audio[key] = entry
        if len(unique) > 100000: raise ValueError('合計標記超過 100000 筆，請分批匯入')
        result = dict(sources[0], title='、'.join(dict.fromkeys(s.get('title', '未命名專案') for s in sources)),
                      marks=list(unique.values()), lookback=0)
        result.pop('ltcAudio', None)
        if audio: result['ltcAudio'] = dict(version=1, format=result['format'], clips=list(audio.values()))
        return result
    from pathlib import Path
    if Path(file_path).stat().st_size > 20 * 1024 * 1024: raise ValueError('JSON 超過 20 MB')
    with open(file_path, encoding='utf-8-sig') as handle:
        shoot = json.load(handle)
    if not isinstance(shoot, dict): raise ValueError('不是有效的 SetMark 專案檔')
    if shoot.get('isTest') is True:
        raise ValueError('這是模擬時間碼的功能測試紀錄，不能對應正式相機素材')
    if not isinstance(shoot, dict) or not isinstance(shoot.get('id'), str) or shoot.get('format') not in FORMATS:
        raise ValueError('不是有效的 SetMark 專案檔')
    marks = shoot.get('marks')
    if not isinstance(marks, list) or len(marks) > 100000:
        raise ValueError('標記清單無效或超過 100000 筆')
    seen = set()
    for mark in marks:
        if not isinstance(mark, dict) or not isinstance(mark.get('id'), str) or not mark['id'] or mark['id'] in seen:
            raise ValueError('標記識別碼無效或重複')
        seen.add(mark['id'])
        if type(mark.get('frame')) is not int or not isinstance(mark.get('tag'), str) or not isinstance(mark.get('note', ''), str):
            raise ValueError('標記時間碼、分類或備註格式無效')
    # Validate every compensation before any new timeline can be created.
    import math
    lookback = shoot.get('lookback', 0)
    if type(lookback) not in (int, float) or not math.isfinite(lookback) or not 0 <= lookback <= 3600:
        raise ValueError('往前保留設定無效')
    for mark in marks:
        if not isinstance(mark.get('author', ''), str): raise ValueError('標記姓名格式無效')
        value = mark.get('lookbackFrames', 0)
        if type(value) is not int or not 0 <= value <= 216000: raise ValueError('標記的往前保留設定無效')
    return shoot

def marker_identities(custom):
    if custom.startswith('setmark:v3:'):
        try:
            values = json.loads(custom[len('setmark:v3:'):])
            if isinstance(values, list) and all(isinstance(v, list) and len(v) == 2 and all(isinstance(x, str) for x in v) for v in values):
                return {tuple(v) for v in values}
        except (ValueError, TypeError): pass
    if custom.startswith('setmark:v2:'):
        project, sep, ids = custom[len('setmark:v2:'):].partition(':')
        if sep and project and ids: return {(project, i) for i in ids.split(',')}
    return set()

def import_marks(resolve, file_path, apply=False, timeline_override=None):
    shoot = read_shoot(file_path)
    nominal, rate, drop = FORMATS[shoot['format']]
    project = resolve.GetProjectManager().GetCurrentProject()
    timeline = timeline_override if timeline_override is not None else (project.GetCurrentTimeline() if project else None)
    if not timeline:
        raise ValueError('請先開啟 Resolve 專案與已按來源時間碼排列的時間軸')
    settings = timeline.GetSettings() if hasattr(timeline, 'GetSettings') else timeline.GetSetting()
    fps = re.search(r'\d+(?:\.\d+)?', str(settings.get('timelineFrameRate', '')))
    if not fps or abs(float(fps.group()) - rate) > 0.01:
        raise ValueError('Resolve 時間軸幀率與 SetMark 專案不一致')
    df = settings.get('timelineDropFrameTimecode')
    if df is None:
        raise ValueError('無法確認時間軸 DF/NDF 設定，已停止匯入')
    if (str(df).lower() in ('1', 'true')) != bool(drop):
        raise ValueError('Resolve 時間軸 DF/NDF 與 SetMark 不一致')
    start = tc_frames(timeline.GetStartTimecode(), nominal, drop)
    # Restore the button-press time once, using each mark's captured lookback.
    # Legacy files only carry the project-wide setting.
    lookback = shoot.get('lookback', 0)
    if type(lookback) not in (int, float) or lookback < 0 or lookback > 3600:
        raise ValueError('往前保留設定無效')
    compensation = int(round(float(lookback) * rate))
    length = timeline.GetEndFrame() - timeline.GetStartFrame()
    day = nominal * 86400 - drop * 1296
    if length <= 0: raise ValueError('時間線沒有可用範圍')
    if length >= day:
        raise ValueError('原型僅支援少於 24 小時的時間軸')
    grouped = defaultdict(list)
    skipped = []
    existing = timeline.GetMarkers() or {}
    imported = set().union(*(marker_identities(m.get('customData', '')) for m in existing.values())) if existing else set()
    repeated_positions = set()
    for mark in shoot['marks']:
        if (mark.get('projectID', shoot['id']), mark['id']) in imported:
            repeated_positions.add((mark['frame'], mark.get('lookbackFrames', compensation))); continue
        per_mark = mark.get('lookbackFrames', compensation)
        if type(per_mark) is not int or per_mark < 0 or per_mark > 216000:
            raise ValueError('標記的往前保留設定無效')
        relative = (int(mark['frame']) + per_mark - start) % day
        if 0 <= relative < length:
            grouped[relative].append(mark)
        else:
            skipped.append(mark['id'])
    existing = timeline.GetMarkers() or {}
    results = {'planned': 0, 'added': 0, 'already_present': len(repeated_positions), 'updated': 0, 'conflicts': [], 'out_of_range': skipped, 'failed': []}
    colors = {'爆笑': 'Yellow', '金句': 'Cyan', '衝突': 'Red', '反應': 'Green', 'NG': 'Pink', '備註': 'Blue', '其他': 'Blue', '開機': 'Cyan'}
    for frame, marks in sorted(grouped.items()):
        keys = {(m.get('projectID', shoot['id']), m['id']) for m in marks}
        old = existing.get(frame)
        known = marker_identities(old.get('customData', '')) if old else set()
        if old and not known:
            results['conflicts'].append(frame); continue
        identity = 'setmark:v3:' + json.dumps(sorted(keys | known), ensure_ascii=False, separators=(',', ':'))
        results['planned'] += 1
        if apply:
            name = ' / '.join(dict.fromkeys(m['tag'] for m in marks))
            note = '\n'.join('【' + m.get('projectTitle', shoot.get('title', '未命名專案')) + '】' + (m.get('author') or '') + ' · ' + m['tag'] + ': ' + m.get('note', '') for m in marks)
            color, duration = colors.get(marks[0]['tag'], 'Blue'), 1
            if old:
                # Resolve allows one marker per frame. Preserve user edits when
                # appending new SetMark records; restore the original on failure.
                name = old.get('name', '') + ' / ' + name
                note = old.get('note', '') + '\n' + note
                color, duration = old.get('color', 'Blue'), old.get('duration', 1)
                if not timeline.DeleteMarkerAtFrame(frame):
                    results['failed'].append(frame); continue
            try:
                ok = timeline.AddMarker(frame, color, name, note, duration, identity)
            except Exception:
                ok = False
            if ok:
                results['added'] += 1
                if old: results['updated'] += 1
            else:
                restored = True
                if old:
                    try:
                        restored = timeline.AddMarker(frame, old.get('color', 'Blue'), old.get('name', ''), old.get('note', ''), old.get('duration', 1), old.get('customData', ''))
                    except Exception:
                        restored = False
                if not restored:
                    # Keep recoverable content if the host refuses both writes.
                    import tempfile
                    from pathlib import Path
                    fd, backup = tempfile.mkstemp(prefix='SetMark-marker-recovery-', suffix='.json')
                    import os
                    with os.fdopen(fd, 'w', encoding='utf-8') as handle: json.dump({'frame': frame, 'marker': old}, handle, ensure_ascii=False)
                    raise ValueError('標記寫入及還原失敗，原標記備份：' + backup)
                results['failed'].append(frame)
    return results

# Resolve Python console example:
# exec(open('/absolute/path/import_markers.py').read())
# print(import_marks(resolve, '/absolute/path/SetMark-....json'))  # Preview only
# print(import_marks(resolve, '/absolute/path/SetMark-....json', apply=True))
