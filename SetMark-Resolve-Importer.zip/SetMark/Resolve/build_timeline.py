"""Integrated source-timecode assembly. Concatenated into the single install script."""
import os
import hashlib
from fractions import Fraction

def media_rate(value):
    match = re.search(r'\d+(?:\.\d+)?', str(value))
    if not match: raise ValueError('無法讀取素材影格率。')
    value = float(match.group())
    for n, d in [(24000,1001),(24,1),(25,1),(30000,1001),(30,1),(50,1),(60000,1001),(60,1)]:
        if abs(value - n/d) < .01: return Fraction(n,d)
    raise ValueError('不支援的素材影格率；請使用固定影格率原始影片。')

def nearest_frame(value):
    return (value.numerator * 2 + value.denominator) // (value.denominator * 2)

def frame_tc(frame, nominal, drop):
    if drop:
        ten = nominal * 600 - drop * 9
        blocks, rest = divmod(frame, ten)
        frame += drop * 9 * blocks + drop * max(0, (rest - drop) // (nominal * 60 - drop))
    seconds, f = divmod(frame, nominal)
    minutes, sec = divmod(seconds, 60)
    hours, minute = divmod(minutes, 60)
    return f'{hours:02}:{minute:02}:{sec:02}{";" if drop else ":"}{f:02}'


def media_bin_index(pool):
    """Keep bin identity, including camera ancestors above card sub-bins."""
    index = {}
    root = pool.GetRootFolder()
    def values(items):
        return list(items.values()) if isinstance(items, dict) else (items or [])
    visited_bins = set()
    def walk(folder, ancestors):
        if len(ancestors) > 64: raise ValueError('Bin 層級過深。')
        if folder.GetUniqueId() in visited_bins: return
        visited_bins.add(folder.GetUniqueId())
        if len(visited_bins) > 5000: raise ValueError('專案 Bin 數量過多。')
        if folder.GetName() in ('_CARD_METADATA','_CardDockRecords','_CardDockReports'): return
        chain = ancestors + [folder]
        candidates = chain[1:]
        camera_bins = [b for b in candidates if re.fullmatch(
            r'(?:P[A-H]|[A-Za-z0-9]+[ _-]*機(?:位)?|機位[ _-]*[A-Za-z0-9]+|(?:cam|camera)[ _-]*[A-Za-z0-9]+|[A-Za-z0-9]+[ _-]*(?:cam|camera))',
            b.GetName().strip(), re.IGNORECASE)]
        owner = camera_bins[-1] if camera_bins else (folder if ancestors else None)
        for clip in values(folder.GetClipList()):
            index[clip.GetUniqueId()] = {'folder': folder,
                'group': 'bin:' + owner.GetUniqueId() if owner else None,
                'label': owner.GetName() if owner else None,
                'path': [(b.GetUniqueId(), b.GetName()) for b in chain]}
        for child in values(folder.GetSubFolderList()): walk(child, chain)
    walk(root, [])
    return index

def plan_audio_lanes(clips, rate):
    """Allocate compatible, nonoverlapping audio independently of video lanes."""
    lanes = []
    for clip in clips:
        raw = str(clip['props'].get('Audio Ch', '0'))
        if not raw.isdigit(): raise ValueError(clip['name'] + '：無法確認音訊聲道數。')
        channels = int(raw)
        if not channels:
            if clip.get('audio_only') or clip['props'].get('Type') == 'Video + Audio':
                raise ValueError(clip['name'] + '：音訊聲道數缺失。')
            clip['audio_lane'] = None
            continue
        # Reserve the longer of exact audio and rounded timeline duration. No
        # shared lane can collide at a fractional-frame source boundary.
        end = clip['start'] + max(Fraction(clip['frames']), clip['source_duration'] * rate)
        key = (clip['group'], channels)
        lane = next((x for x in lanes if x['key'] == key and x['end'] <= clip['start']), None)
        if lane is None:
            lane = dict(key=key, number=len(lanes)+1, label=clip['label'], channels=channels, end=0)
            lanes.append(lane)
        clip['audio_lane'] = lane['number']
        lane['end'] = end
    return lanes

def source_plan(resolve, file_path):
    shoot = read_shoot(file_path)
    nominal, rate, drop = FORMATS[shoot['format']]
    project = resolve.GetProjectManager().GetCurrentProject()
    if not project: raise ValueError('請先開啟 Resolve 專案。')
    pool = project.GetMediaPool()
    root_bin = pool.GetCurrentFolder()
    if not root_bin: raise ValueError('請先在媒體池左側開啟要處理的最上層 Bin。')
    selected, visited, seen_items = [], set(), set()
    def collect(folder, depth=0):
        if depth > 64: raise ValueError('Bin 層級過深，請分批處理。')
        if folder.GetName() in ('_CARD_METADATA','_CardDockRecords','_CardDockReports'): return
        uid = folder.GetUniqueId()
        if uid in visited: return
        visited.add(uid)
        if len(visited) > 5000: raise ValueError('Bin 數量過多，請選較小的範圍。')
        items = folder.GetClipList() or []
        if isinstance(items, dict): items = list(items.values())
        for clip in items:
            if clip.GetUniqueId() not in seen_items:
                seen_items.add(clip.GetUniqueId()); selected.append(clip)
                if len(selected) > 2000: raise ValueError('Bin 內超過 2,000 個項目，請分批處理。')
        children = folder.GetSubFolderList() or []
        if isinstance(children, dict): children = list(children.values())
        for child in children: collect(child, depth+1)
    collect(root_bin)
    if not selected: raise ValueError('目前 Bin 及子 Bin 沒有素材。')
    ltc = shoot.get('ltcAudio', {})
    if ltc and (ltc.get('version') != 1 or ltc.get('format') != shoot['format']): raise ValueError('LTC 同步資料版本／格式不符。')
    audio_map = {}
    for entry in ltc.get('clips', []):
        key = os.path.normcase(os.path.abspath(entry['path']))
        if key in audio_map: raise ValueError('LTC 音訊清單重複。')
        audio_map[key] = entry
    used_audio = set()
    skipped = []
    bins = media_bin_index(pool)
    source_folders = {}
    clips = []
    seen = set()
    for clip in selected:
        props = clip.GetClipProperty()
        name = clip.GetName()
        audio_entry = audio_map.get(os.path.normcase(os.path.abspath(props.get('File Path', '') or '.')))
        if props.get('Type') not in ('Video', 'Video + Audio') and not audio_entry:
            skipped.append(name + '：略過圖片、純音訊或非原始影片'); continue
        uid = clip.GetUniqueId()
        if uid in seen: raise ValueError('選取素材有重複。')
        seen.add(uid)
        path = props.get('File Path', '')
        if not path or not os.path.isfile(path): raise ValueError(name + '：素材離線或不是一般影片檔。請先連結原始素材。')
        if audio_entry:
            import wave
            h = hashlib.sha256()
            with open(path, 'rb') as stream:
                for chunk in iter(lambda: stream.read(1024*1024), b''): h.update(chunk)
            if h.hexdigest() != audio_entry['sha256']: raise ValueError(name + '：LTC 音訊副本已變更，請重新準備。')
            with wave.open(path, 'rb') as w:
                if (w.getframerate(), w.getnframes(), w.getnchannels()) != (audio_entry['sampleRate'], audio_entry['sampleFrames'], audio_entry['channels']): raise ValueError('LTC WAV 資料不符。')
            used_audio.add(os.path.normcase(os.path.abspath(path)))
            source_rate = media_rate(rate)
            source_start = Fraction(int(audio_entry['startTicks']),254016000000)
            source_duration = Fraction(audio_entry['sampleFrames'],audio_entry['sampleRate'])
            if source_start < 0 or source_duration <= 0: raise ValueError('LTC 音訊時間不正確。')
            frame = nearest_frame(source_start * source_rate)
            timeline_frames = nearest_frame(source_duration * source_rate)
            info = bins[uid]
            source_folders[info['folder'].GetUniqueId()] = info['folder']
            clips.append(dict(item=clip,id=uid,name=name,tc=frame_tc(frame,nominal,drop),start=frame,frames=timeline_frames,
                source_frames=timeline_frames,source_rate=source_rate,source_start=Fraction(0),source_duration=source_duration,props=props,
                group='audio:'+info['group'] if info['group'] else 'audio:'+uid,label=info['label'] or 'LTC 收音',camera='',bin_path=info['path'],audio_only=True))
            continue
        source_rate = media_rate(props.get('FPS', ''))
        target_rate = media_rate(rate)
        raw_frames = str(props.get('Frames', ''))
        if not raw_frames.isdigit() or int(raw_frames) <= 0: raise ValueError(name + '：無法讀取完整素材長度。')
        tc = str(props.get('Start TC', ''))
        if not re.fullmatch(r'\d{2}:\d{2}:\d{2}[:;]\d{2}', tc): raise ValueError(name + '：缺少可辨識的來源時間碼。')
        source_nominal = round(source_rate)
        source_drop = (2 if source_nominal == 30 else 4) if ';' in tc and source_rate.denominator == 1001 and source_nominal in (30,60) else 0
        if ';' in tc and not source_drop: raise ValueError(name + '：素材時間碼與影格率不相容。')
        if source_rate.denominator == 1001 and source_nominal in (30,60) and bool(drop) != bool(source_drop):
            raise ValueError(name + '：素材 DF／NDF 與 JSON 不一致，請核對共用時間碼。')
        # Resolve media-pool Start TC is interpreted at the media playback rate,
        # not at the camera LCD's potentially half-rate TC display.
        source_start = Fraction(tc_frames(tc, source_nominal, source_drop), 1) / source_rate
        source_duration = Fraction(int(raw_frames), 1) / source_rate
        frame = nearest_frame(source_start * target_rate)
        timeline_frames = nearest_frame(source_duration * target_rate)
        if timeline_frames < 1: raise ValueError(name + '：素材短於一個時間線影格。')
        metadata = clip.GetMetadata() or {}
        camera = str(metadata.get('Camera #') or metadata.get('Camera ID') or '').strip()
        folder = os.path.dirname(path)
        bin_info = bins.get(uid)
        if not bin_info: raise ValueError(name + '：找不到素材所屬 Bin，請重新選取素材。')
        source_folders[bin_info['folder'].GetUniqueId()] = bin_info['folder']
        carddock = re.fullmatch(r'([A-H])cam|P[A-H]', str(bin_info['label'] or ''), re.I)
        if carddock: camera = ''
        group = 'camera:' + camera if camera else (bin_info['group'] or 'folder:' + folder)
        label = '機位 ' + camera if camera else (bin_info['label'] or os.path.basename(folder) or '自動分軌')
        if carddock and carddock.group(1): label=carddock.group(1).upper()+'機'
        clips.append({'item': clip, 'id': uid, 'name': name, 'tc': tc, 'start': frame, 'frames': timeline_frames, 'source_frames': int(raw_frames), 'source_rate': source_rate, 'source_start': source_start, 'source_duration': source_duration, 'props': props,
                      'group': group, 'label': label, 'camera': camera, 'bin_path': bin_info['path']})
    if used_audio != set(audio_map): raise ValueError('請把全部 LTC 輸出 audio 副本匯入目前 Bin 或子 Bin，再建線。')
    if not clips: raise ValueError('目前 Bin 及子 Bin 沒有可同步的原始影片；圖片、純音訊與巢狀時間線不支援。')
    clips.sort(key=lambda c: (c['start'], c['id']))
    origin = clips[0]['start']
    end = origin
    day = nominal * 86400 - drop * 1296
    for clip in clips:
        end = max(end, clip['start'] + clip['frames'])
        if end > day: raise ValueError('素材跨過午夜，請先分段處理；本版不會猜測拍攝日期。')
    lanes = []
    for clip in clips:
        lane = next((lane for lane in lanes if lane['group'] == clip['group'] and lane['end'] <= clip['start']), None)
        if lane is None:
            lane = {'group': clip['group'], 'label': clip['label'], 'number': len(lanes) + 1, 'end': 0}
            lanes.append(lane)
        clip['lane'] = -lane['number'] if clip.get('audio_only') else lane['number']
        lane['end'] = clip['start'] + clip['frames']
    # Higher video track numbers appear above lower ones: A is visually on top.
    video_lanes = [l for l in lanes if not l['group'].startswith('audio:')]
    def natural(label):
        m = re.fullmatch(r'([A-H])機',label,re.I)
        prefix = '0'+m.group(1).upper() if m else ('1'+label.upper() if re.fullmatch(r'P[A-H]',label,re.I) else '2'+label)
        return [int(v) if v.isdigit() else v.casefold() for v in re.split(r'(\d+)',prefix)]
    ordered = sorted(video_lanes, key=lambda l:natural(l['label']))
    mapping = {l['number']:len(ordered)-i for i,l in enumerate(ordered)}
    for c in clips:
        if not c.get('audio_only'): c['lane']=mapping[c['lane']]
    for l in video_lanes: l['number']=mapping[l['number']]
    if end - origin > nominal * 43200:
        raise ValueError('素材時間跨度超過 12 小時，可能跨日。請按拍攝時段分開選取。')
    audio_lanes = plan_audio_lanes(clips, media_rate(rate))
    result = {'audio_lanes': audio_lanes, 'project': project, 'pool': pool, 'clips': clips, 'start': origin, 'tc': frame_tc(origin, nominal, drop),
              'length': end - origin, 'format': shoot['format'], 'title': shoot.get('title') or 'SetMark', 'lanes': lanes, 'source_folders': list(source_folders.values()), 'scope': root_bin.GetName(), 'skipped': skipped}
    signature = [project.GetUniqueId(), root_bin.GetUniqueId(), root_bin.GetName(), skipped, shoot, [(c['id'], c['props'], c['group'], c['label'], c['bin_path'], c['lane']) for c in clips]]
    result['fingerprint'] = hashlib.sha256(json.dumps(signature, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    result['preview'] = import_marks(resolve, file_path, timeline_override=SourcePreview(result))
    return result

class SourcePreview:
    def __init__(self, plan): self.plan = plan
    def GetSettings(self):
        _, rate, drop = FORMATS[self.plan['format']]
        return {'timelineFrameRate': str(rate), 'timelineDropFrameTimecode': str(int(bool(drop)))}
    def GetStartTimecode(self): return self.plan['tc']
    def GetStartFrame(self): return self.plan['start']
    def GetEndFrame(self): return self.plan['start'] + self.plan['length']
    def GetMarkers(self): return {}

def timeline_xml(plan, name):
    from fractions import Fraction
    from pathlib import Path
    import xml.etree.ElementTree as ET
    nominal, rate, drop = FORMATS[plan['format']]
    fractional = plan['format'].startswith(('23.976', '29.97', '59.94'))
    num, den = (nominal * 1000, 1001) if fractional else (nominal, 1)
    def seconds(frames):
        value = Fraction(frames * den, num)
        return str(value.numerator) + '/' + str(value.denominator) + 's'
    root = ET.Element('fcpxml', version='1.7')
    resources = ET.SubElement(root, 'resources')
    resolution = str(plan['clips'][0]['props'].get('Resolution', '1920x1080'))
    size = re.findall(r'\d+', resolution)
    width, height = size[:2] if len(size) >= 2 else ('1920', '1080')
    ET.SubElement(resources, 'format', id='r1', frameDuration=seconds(1), width=width, height=height)
    def rational_seconds(value):
        return str(value.numerator) + '/' + str(value.denominator) + 's'
    for index, clip in enumerate(plan['clips'], 2):
        fid = 'f' + str(index)
        clip_size = re.findall(r'\d+', str(clip['props'].get('Resolution', resolution)))
        cw, ch = clip_size[:2] if len(clip_size) >= 2 else (width,height)
        ET.SubElement(resources, 'format', id=fid, frameDuration=rational_seconds(1/clip['source_rate']), width=cw, height=ch)
        attributes = dict(id='r'+str(index), name=clip['name'], src=Path(clip['props']['File Path']).as_uri(),
            start=rational_seconds(clip['source_start']), duration=rational_seconds(clip['source_duration']), hasVideo='0' if clip.get('audio_only') else '1', format=fid)
        audio = str(clip['props'].get('Audio Ch', '0'))
        if audio.isdigit() and int(audio) > 0: attributes.update(hasAudio='1', audioSources='1', audioChannels=audio)
        ET.SubElement(resources, 'asset', **attributes)
    library = ET.SubElement(root, 'library')
    event = ET.SubElement(library, 'event', name='SetMark')
    project = ET.SubElement(event, 'project', name=name)
    sequence = ET.SubElement(project, 'sequence', format='r1', duration=seconds(plan['length']),
        tcStart=seconds(plan['start']), tcFormat='DF' if drop else 'NDF')
    spine = ET.SubElement(sequence, 'spine')
    # Connected lanes over one full-length gap preserve independent cameras and stops.
    anchor = ET.SubElement(spine, 'gap', name='共用時間碼', offset=seconds(plan['start']), start='0s', duration=seconds(plan['length']))
    for index, clip in enumerate(plan['clips'], 2):
        attrs = dict(ref='r'+str(index), name=clip['name'], offset=seconds(clip['start'] - plan['start']),
            start=rational_seconds(clip['source_start']), duration=seconds(clip['frames']), tcFormat='DF' if ';' in clip['tc'] else 'NDF')
        if not clip.get('audio_only'):
            video_attrs = {k:v for k,v in attrs.items() if k != 'ref'}
            video_clip = ET.SubElement(anchor, 'clip', **video_attrs, lane=str(clip['lane']))
            ET.SubElement(video_clip, 'video', ref=attrs['ref'], offset=attrs['start'], start=attrs['start'], duration=attrs['duration'])
        if clip['audio_lane'] is not None:
            audio_attrs = {k:v for k,v in attrs.items() if k != 'ref'}
            audio_clip = ET.SubElement(anchor, 'clip', **audio_attrs, lane=str(-clip['audio_lane']))
            ET.SubElement(audio_clip, 'audio', ref=attrs['ref'], offset=attrs['start'], start=attrs['start'], duration=attrs['duration'], role='dialogue.SetMark'+str(clip['audio_lane']))
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)

def build_and_import(resolve, file_path, expected):
    plan = source_plan(resolve, file_path)
    if plan['fingerprint'] != expected: raise ValueError('JSON、選取素材或專案已變更，請重新檢查。')
    project, pool = plan['project'], plan['pool']
    old = project.GetCurrentTimeline()
    from datetime import datetime
    name = 'SetMark_' + str(plan['title'])[:70] + '_' + datetime.now().strftime('%m%d_%H%M%S_%f')
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory(prefix='setmark-') as folder:
        xml = Path(folder) / 'timeline.fcpxml'
        xml.write_bytes(timeline_xml(plan, name))
        created = pool.ImportTimelineFromFile(str(xml), {'timelineName': name, 'importSourceClips': False, 'sourceClipsFolders': plan['source_folders']})
    if not created: raise ValueError('Resolve 無法依素材時間碼建立時間線。')
    try:
        if not project.SetCurrentTimeline(created): raise ValueError('無法切換至新時間線。')
        settings = created.GetSettings() if callable(getattr(created, 'GetSettings', None)) else created.GetSetting()
        nominal, rate, drop = FORMATS[plan['format']]
        fps = re.search(r'\d+(?:\.\d+)?', str(settings.get('timelineFrameRate', '')))
        if not fps or abs(float(fps.group()) - rate) > .01 or (str(settings.get('timelineDropFrameTimecode')).lower() in ('1', 'true')) != bool(drop):
            raise ValueError('新時間線的影格率或 DF／NDF 設定核對失敗。')
        if tc_frames(created.GetStartTimecode(), nominal, drop) != plan['start']: raise ValueError('新時間線起始時間碼核對失敗。')
        base = created.GetStartFrame()
        # Validate actual video placement and source offsets; the API may reject/ignore parameters.
        videos = []
        actual_tracks = {}
        for track in range(1, created.GetTrackCount('video') + 1):
            for item in created.GetItemListInTrack('video', track) or []:
                videos.append(item)
                actual_tracks[item.GetMediaPoolItem().GetUniqueId()] = track
        if len(videos) != sum(not c.get('audio_only') for c in plan['clips']): raise ValueError('新增的影片數量與選取素材不一致：預期 %d，實際 %d。' % (sum(not c.get('audio_only') for c in plan['clips']), len(videos)))
        by_id = {v.GetMediaPoolItem().GetUniqueId(): v for v in videos}
        for clip in plan['clips']:
            if clip.get('audio_only'): continue
            item = by_id.get(clip['id'])
            target = base + clip['start'] - plan['start']
            if not item or item.GetStart() != target or item.GetDuration() != clip['frames'] or item.GetLeftOffset() != 0:
                raise ValueError('素材實際位置或長度核對失敗：' + clip['name'])
        lane_tracks = {}
        for clip in plan['clips']:
            if clip.get('audio_only'): continue
            lane_tracks.setdefault(clip['lane'], set()).add(actual_tracks[clip['id']])
        if any(len(tracks) != 1 for tracks in lane_tracks.values()) or len(set(next(iter(t)) for t in lane_tracks.values())) != len(lane_tracks):
            raise ValueError('多機素材分軌核對失敗。')
        actual_order = [next(iter(lane_tracks[k])) for k in sorted(lane_tracks)]
        if actual_order != sorted(actual_order): raise ValueError('機位軌道上下順序不符，已停止。')
        for lane in plan['lanes']:
            if lane['group'].startswith('audio:') or lane['number'] not in lane_tracks: continue
            created.SetTrackName('video', next(iter(lane_tracks[lane['number']])), 'SetMark ' + str(lane['number']) + ' · ' + lane['label'])
        # Verify the importer actually reused the intended track blocks. XML
        # lanes alone are not evidence of the native Resolve track layout.
        audios = {}
        tracks = {}
        for track in range(1, created.GetTrackCount('audio') + 1):
            items = created.GetItemListInTrack('audio', track) or []
            tracks[track] = items
            for item in items:
                audios.setdefault(item.GetMediaPoolItem().GetUniqueId(), []).append((track, item))
        expected_ids = {c['id'] for c in plan['clips'] if c['audio_lane'] is not None}
        if set(audios) != expected_ids: raise ValueError('素材音訊缺失或出現未預期的音訊。')
        blocks = {}
        for clip in plan['clips']:
            if clip['audio_lane'] is None: continue
            audio = audios[clip['id']]
            target = base + clip['start'] - plan['start']
            if any(a.GetStart() != target or a.GetDuration() != clip['frames'] or a.GetLeftOffset() != 0 for _, a in audio):
                raise ValueError('素材音訊位置、長度或來源偏移核對失敗：' + clip['name'])
            occupied = frozenset(t for t, _ in audio)
            if len(occupied) != len(audio): raise ValueError('素材音訊在同一軌重複。')
            lane = clip['audio_lane']
            if lane in blocks and blocks[lane] != occupied:
                raise ValueError('Resolve 未重用同機位音軌：' + clip['name'])
            blocks[lane] = occupied
        owners = {}
        for lane, occupied in blocks.items():
            for track in occupied:
                if track in owners: raise ValueError('不同機位或音訊配置混入同一音軌。')
                owners[track] = lane
        for track, items in tracks.items():
            ordered = sorted(items, key=lambda x: x.GetStart())
            if any(a.GetStart()+a.GetDuration() > b.GetStart() for a,b in zip(ordered, ordered[1:])):
                raise ValueError('音軌內素材重疊，已停止。')
        for lane in plan['audio_lanes']:
            for channel, track in enumerate(sorted(blocks.get(lane['number'], [])), 1):
                created.SetTrackName('audio', track, 'SetMark · ' + lane['label'] + ' · ' + str(channel))
        if created.GetEndFrame() - base != plan['length']: raise ValueError('時間線實際長度不符，已停止匯入。')
        result = import_marks(resolve, file_path, apply=True)
        result['timeline_name'] = created.GetName()
        result['video_lanes'] = sum(not l['group'].startswith('audio:') for l in plan['lanes'])
        result['audio_blocks'] = len(plan['audio_lanes'])
        return result
    except Exception as exc:
        # Keep failed output visible for diagnosis; never present it as verified.
        failed_name = '未驗證_勿剪輯_' + name
        try:
            created.SetName(failed_name)
        except Exception:
            failed_name = name
        try:
            project.SetCurrentTimeline(created)
        except Exception:
            pass
        raise ValueError('建立未完成：' + str(exc) + '\n本次時間線已保留：' + failed_name + '\n尚未通過檢查，請勿用於正式剪輯。') from exc
