def choose_json_files(fusion, bmd):
    """Use Fusion controls so no additional Python GUI package is needed."""
    from pathlib import Path
    seed = fusion.RequestFile()
    if not seed: return None
    seed = Path(seed).expanduser()
    paths = sorted(p for p in seed.parent.iterdir() if p.is_file() and p.suffix.lower() == '.json')
    if len(paths) > 1000: raise ValueError('資料夾超過 1000 個 JSON，請先縮小範圍')
    if seed not in paths: raise ValueError('請先選一個 JSON，再勾選同資料夾內要合併的檔案')
    ui = fusion.UIManager
    dispatch = bmd.UIDispatcher(ui)
    selected, page, output = {seed}, [paths.index(seed) // 10], []
    rows = [ui.CheckBox({'ID': 'File%d' % i, 'Text': '', 'Weight': 0}) for i in range(10)]
    dialog = dispatch.AddWindow({'ID': 'MultiJSON', 'WindowTitle': '選擇同一天的 JSON（可多選）', 'Geometry': [220, 200, 820, 500]}, ui.VGroup([
        ui.Label({'Text': '勾選要合併的專案；只選同一天、持續 Free Run 的紀錄。', 'Weight': 0}),
        *rows,
        ui.Label({'ID': 'Page', 'Text': '', 'Weight': 0}),
        ui.HGroup({'Weight': 0}, [ui.Button({'ID': 'Prev', 'Text': '上一頁'}), ui.Button({'ID': 'Next', 'Text': '下一頁'}),
            ui.Button({'ID': 'All', 'Text': '全選'}), ui.Button({'ID': 'Clear', 'Text': '全不選'})]),
        ui.HGroup({'Weight': 0}, [ui.Button({'ID': 'OK', 'Text': '使用所選 JSON'}), ui.Button({'ID': 'Cancel', 'Text': '取消'})])]))
    items = dialog.GetItems()
    def collect():
        for i in range(10):
            index = page[0] * 10 + i
            if index < len(paths):
                if items['File%d' % i].Checked: selected.add(paths[index])
                else: selected.discard(paths[index])
    def render():
        for i in range(10):
            index = page[0] * 10 + i
            row = items['File%d' % i]
            row.Enabled = index < len(paths)
            row.Text = paths[index].name if index < len(paths) else ''
            row.Checked = index < len(paths) and paths[index] in selected
        items['Page'].Text = '第 %d / %d 頁（最多選 100 個檔案）' % (page[0]+1, (len(paths)+9)//10)
        items['Prev'].Enabled = page[0] > 0
        items['Next'].Enabled = (page[0]+1)*10 < len(paths)
    def move(delta):
        collect(); page[0] += delta; render()
    def all_files(value):
        selected.clear()
        if value: selected.update(paths[:100])
        render()
    def accept(ev):
        collect()
        if not 1 <= len(selected) <= 100:
            items['Page'].Text = '請選擇 1～100 個 JSON'; return
        output.extend(p for p in paths if p in selected); dispatch.ExitLoop()
    dialog.On.Prev.Clicked = lambda ev: move(-1)
    dialog.On.Next.Clicked = lambda ev: move(1)
    dialog.On.All.Clicked = lambda ev: all_files(True)
    dialog.On.Clear.Clicked = lambda ev: all_files(False)
    dialog.On.OK.Clicked = accept
    dialog.On.Cancel.Clicked = lambda ev: dispatch.ExitLoop()
    dialog.On.MultiJSON.Close = lambda ev: dispatch.ExitLoop()
    render(); dialog.Show(); dispatch.RunLoop(); dialog.Hide()
    return output or None

def launch(resolve, fusion, bmd):
    import hashlib
    from pathlib import Path
    ui = fusion.UIManager
    dispatcher = bmd.UIDispatcher(ui)
    win = dispatcher.AddWindow({'ID': 'SetMarkImport', 'WindowTitle': 'SetMark · 匯入 JSON 標記', 'Geometry': [180, 180, 760, 600]}, ui.VGroup([
        ui.Label({'Text': '建立素材時間碼時間線，或將 JSON 標記匯入目前時間線。', 'Weight': 0}),
        ui.TextEdit({'ID': 'Path', 'AcceptRichText': False, 'PlainText': '', 'MaximumSize': [16777215, 85]}),
        ui.Button({'ID': 'Browse', 'Text': '選擇 JSON（同資料夾可多選；也可在上方每行貼一個路徑）', 'Weight': 0}),
        ui.CheckBox({'ID': 'NewTimeline', 'Text': '依目前 Bin 與子 Bin 建立一條時間線，並匯入所有 JSON', 'Checked': False, 'Weight': 0}),
        ui.Label({'Text': '建立新時間線：先在媒體池開啟最上層 Bin；依 Camera #、媒體池 Bin 或來源資料夾分軌，重疊素材自動拆軌。', 'WordWrap': True, 'Weight': 0}),
        ui.CheckBox({'ID': 'Aligned', 'Text': '我已確認：時間線時間碼與素材來源時間碼對齊', 'Checked': False, 'Weight': 0}),
        ui.TextEdit({'ID': 'Report', 'ReadOnly': True, 'AcceptRichText': False, 'PlainText': '選擇檔案後按「檢查標記」。'}),
        ui.HGroup({'Weight': 0}, [ui.Button({'ID': 'Preview', 'Text': '檢查標記'}), ui.Button({'ID': 'Apply', 'Text': '匯入標記', 'Enabled': False}), ui.Button({'ID': 'Close', 'Text': '關閉'})])
    ]))
    items = win.GetItems()
    state = {}
    def timeline():
        project = resolve.GetProjectManager().GetCurrentProject()
        t = project.GetCurrentTimeline() if project else None
        if not t: raise ValueError('請先開啟需要加入標記的時間線。')
        return t
    def fingerprint(path):
        t = timeline()
        return (tuple((str(p), hashlib.sha256(p.read_bytes()).hexdigest()) for p in path), t.GetUniqueId(), t.GetStartTimecode(), t.GetEndFrame(), repr(t.GetMarkers()), repr((t.GetSettings() if callable(getattr(t, 'GetSettings', None)) else t.GetSetting())))
    def invalidate(ev=None):
        state.clear(); items['Apply'].Enabled = False
    def report(result):
        return ('可新增：%d 個位置\n已匯入：%d\n同位置衝突：%d\n時間線範圍外：%d\n' % (result['planned'], result['already_present'], len(result['conflicts']), len(result['out_of_range'])))
    def browse(ev):
        try:
            chosen = choose_json_files(fusion, bmd)
            if chosen: items['Path'].PlainText = '\n'.join(str(p) for p in chosen); invalidate()
        except Exception as exc: items['Report'].PlainText = '無法開啟選檔視窗，請貼上 JSON 完整路徑。\n' + str(exc)
    def preview(ev):
        invalidate()
        try:
            path = [Path(line.strip()).expanduser() for line in items['Path'].PlainText.splitlines() if line.strip()]
            data = read_shoot(path)
            new = bool(items['NewTimeline'].Checked)
            if new:
                plan = source_plan(resolve, path)
                result = plan['preview']
                heading = '將建立新時間線；起始：' + plan['tc'] + '\n素材：' + str(len(plan['clips'])) + ' 個，影片軌道：' + str(len(plan['lanes'])) + ' 軌（保留停機空隙）' + '\n' + '\n'.join('軌 ' + str(lane['number']) + '：' + lane['label'] for lane in plan['lanes'])
                stamp = plan['fingerprint']
            else:
                result = import_marks(resolve, path)
                heading = '時間線：' + timeline().GetName()
                stamp = fingerprint(path)
            items['Report'].PlainText = (heading + '\n專案：' + data.get('title', '') + '\n格式：' + data['format'] + '\n已補回每個標記各自的往前保留時間，匯入點為按下按鈕的時間。\n\n' + report(result) + '\n' + '\n'.join((m.get('author') or '') + ' · ' + m['tag'] + ('：' + m.get('note', '') if m.get('note') else '') for m in data['marks'][:100]) + '\n\n範圍外的點會略過；既有 SetMark 同位置追加備註，手動標記不會覆蓋。')
            state.update(path=path, fingerprint=stamp, new=new, planned=result['planned'])
            items['Apply'].Enabled = bool(new or (items['Aligned'].Checked and result['planned']))
        except Exception as exc: items['Report'].PlainText = '尚未匯入：' + str(exc)
    def apply(ev):
        try:
            if not state or (not state.get('new') and not items['Aligned'].Checked): raise ValueError('請先確認對齊並重新檢查。')
            path = state['path']
            items['Apply'].Enabled = False
            if state['new']:
                result = build_and_import(resolve, path, state['fingerprint'])
                items['NewTimeline'].Checked = False
                items['Aligned'].Checked = True
                items['Aligned'].Enabled = True
                items['Apply'].Text = '匯入標記'
            else:
                if fingerprint(path) != state['fingerprint']: raise ValueError('檔案或時間線已變更，請重新檢查。')
                result = import_marks(resolve, path, apply=True)
            items['Report'].PlainText = ('已建立時間線：' + result['timeline_name'] + '\n' if 'timeline_name' in result else '') + '已新增 %d 個標記。\n失敗：%d\n\n%s\n請儲存 Resolve 專案。' % (result['added'],len(result['failed']),report(result))
            state.clear()
        except Exception as exc:
            invalidate(); items['Report'].PlainText = '匯入未完成：' + str(exc) + '\n可重新檢查；已成功加入的點不會重複加入。'
            print(items['Report'].PlainText)
            win.Show()
    win.On.Browse.Clicked = browse
    win.On.Preview.Clicked = preview
    win.On.Apply.Clicked = apply
    win.On.Path.TextChanged = invalidate
    def mode_changed(ev):
        invalidate()
        new = bool(items['NewTimeline'].Checked)
        items['Aligned'].Enabled = not new
        items['Apply'].Text = '建立時間線並匯入' if new else '匯入標記'
        items['Report'].PlainText = '請重新按「檢查標記」。'
    def alignment_changed(ev):
        items['Apply'].Enabled = bool(state and (state.get('new') or (items['Aligned'].Checked and state.get('planned'))))
    win.On.NewTimeline.Clicked = mode_changed
    win.On.Aligned.Clicked = alignment_changed
    win.On.Close.Clicked = lambda ev: dispatcher.ExitLoop()
    win.On.SetMarkImport.Close = lambda ev: dispatcher.ExitLoop()
    win.Show()
    dispatcher.RunLoop()
    win.Hide()

if 'resolve' in globals() and 'fusion' in globals() and 'bmd' in globals():
    launch(resolve, fusion, bmd)
