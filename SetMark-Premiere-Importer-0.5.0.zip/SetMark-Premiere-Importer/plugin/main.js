"use strict";
const fs = require("uxp").storage.localFileSystem;
const host = require("./host.js").createHost(require("premierepro"));
const assembly = require("./assembly.js").createAssembly(require("premierepro"), host);
const $ = id => document.getElementById(id);
let file = null, review = null, busy = false;
function controls() {
  $("choose").disabled = busy;
  $("preview").disabled = busy || !file;
  const building = $("newSequence").checked;
  $("newSequence").disabled = busy;
  $("aligned").disabled = busy || building;
  $("import").textContent = building ? "3. 建立時間線並匯入" : "3. 匯入標記";
  $("import").disabled = busy || !review || (!building && (!review.plan.additions.length || !$("aligned").checked));
  $("hint").textContent = !review ? "請先按「檢查標記」。" : building ? "將建立新時間線，沿用素材時間碼並保留停機空隙。" : !review.plan.additions.length ? "目前沒有可新增的標記，請查看上方結果。" :
    !$("aligned").checked ? "確認時間碼已對齊後，勾選上方方框即可匯入。" : "可以匯入；完成後可在 Premiere 復原這次操作。";
}
async function operation(fn) {
  if (busy) return;
  busy = true; controls();
  try { await fn(); }
  catch (e) { review = null; $("aligned").checked = false; $("status").textContent = "未完成：" + (e.message || String(e)); }
  finally { busy = false; controls(); }
}
async function readFile() {
  const metadata = await file.getMetadata();
  if (metadata.size > 20 * 1024 * 1024) throw Error("JSON 超過 20 MB，請分次匯出。");
  return await file.read();
}
function showReview() {
  const p = review.plan;
  const lines = ["時間線：" + review.state.name, "專案：" + review.data.title,
    "格式：" + review.data.format + "　起始：" + p.startTC,
    "已補回各筆往前保留；以下為按下按鈕的時間。", "",
    "可新增：" + p.additions.length + " 個位置",
    "已匯入，略過：" + p.repeated + " 筆", "同位置已有標記，略過：" + p.conflict + " 筆",
    "時間線範圍外，略過：" + p.outside + " 筆", ""];
  if (review.mode === "new") lines.push("將依來源時間碼放入 " + review.clips.length + " 段素材，分成 " + review.lanes.length + " 條影像軌，保留停機空隙。", ...review.lanes.map((l, i) => "V" + (i + 1) + "：" + (l.label || l.group)), "相機音訊按素材分配獨立音軌。", "混合 fps 維持原速；起點與長度對齊最近時間線格（最多半格）。", "");
  if (review.skipped && review.skipped.length) lines.push("略過 " + review.skipped.length + " 個非原始影片項目：", ...review.skipped.slice(0, 100), "");
  for (const m of p.additions.slice(0, 200)) {
    lines.push(m.tc + "　" + m.name);
    lines.push(m.comments.split("\n\n[SetMark:v1:")[0], "");
  }
  if (p.additions.length > 200) lines.push("預覽顯示前 200 個位置；匯入會處理全部可新增標記。");
  $("report").value = lines.join("\n");
  $("status").textContent = review.mode === "new" ? "檢查完成，可以建立時間線並匯入。" : p.additions.length ? "檢查完成，請確認時間線後匯入。" : "檢查完成，沒有可新增的標記。";
}
$("choose").addEventListener("click", () => operation(async () => {
  const picked = await fs.getFileForOpening({ types: ["json"], allowMultiple: false });
  if (!picked) return;
  file = picked; review = null; $("aligned").checked = false; $("report").value = "";
  $("filename").textContent = file.name;
  $("status").textContent = "已選擇檔案，請按「檢查標記」。";
}));
$("preview").addEventListener("click", () => operation(async () => {
  review = null; $("aligned").checked = false;
  $("status").textContent = "正在檢查…";
  const raw = await readFile();
  review = await ($("newSequence").checked ? assembly.preview(raw) : host.preview(raw)); showReview();
}));
$("newSequence").addEventListener("change", () => {
  review = null; $("aligned").checked = false; $("report").value = "";
  $("status").textContent = "模式已切換，請重新檢查標記。"; controls();
});
$("aligned").addEventListener("change", controls);
$("import").addEventListener("click", () => operation(async () => {
  $("status").textContent = "正在匯入…";
  const building = review && review.mode === "new";
  const result = building ? await assembly.commit(review, await readFile()) : { count: await host.commit(review, await readFile(), $("aligned").checked) };
  const count = result.count;
  $("newSequence").checked = false;
  review = null; $("aligned").checked = false;
  $("status").textContent = (building ? "已建立「" + result.name + "」。" : "") + "已新增 " + count + " 個時間線標記。請儲存 Premiere 專案。";
  $("report").value = "匯入完成。\n可在 Premiere 的標記面板查看姓名與備註。\n再按「檢查標記」，可確認重複項目已略過。";
}));
controls();
