"use strict";
const core = require("./core.js");

function sourceFormat(rate) {
  for (const name of Object.keys(core.FORMATS)) {
    const f = core.format(name);
    if (Number.isFinite(rate) && Math.abs(rate - f.num/f.den) < .01) return f;
  }
  throw Error("不支援的素材影格率；請使用固定影格率原始影片。");
}
function roundTicks(ticks, timebase) {
  const t = BigInt(ticks), base = BigInt(timebase);
  if (t < 0n) throw Error("來源時間不能是負數。");
  const value = Number((t * 2n + base) / (base * 2n));
  if (!Number.isSafeInteger(value)) throw Error("來源時間超出範圍。");
  return value;
}
function cameraGroup(path) {
  const parts = String(path || "").replace(/\\/g, "/").split("/").slice(0, -1);
  const camera = parts.find(p => /^(?:[A-Z0-9]+機|(?:cam(?:era)?)[ _-]*[A-Z0-9]+)$/i.test(p));
  return camera || parts.join("/") || "未分類";
}
function layout(data, clips, projectID) {
  const f = core.format(data.format);
  if (!clips.length) throw Error("請先在 PR 專案面板選取原始影片。");
  const sorted = clips.map(c => ({ ...c, group: c.group || cameraGroup(c.path) })).sort((a, b) => a.start - b.start || a.id.localeCompare(b.id));
  const ids = new Set(), lanes = []; let end = sorted[0].start;
  for (const clip of sorted) {
    if (ids.has(clip.id)) throw Error("素材重複，請重新選取。");
    ids.add(clip.id);
    sourceFormat(clip.rate);
    if (!Number.isSafeInteger(clip.start) || !Number.isSafeInteger(clip.frames) || clip.frames <= 0 || clip.start < 0) throw Error("無法確認完整素材時間。");
    let lane = lanes.findIndex(l => l.group === clip.group && l.end <= clip.start);
    if (lane < 0) { lane = lanes.length; lanes.push({ group: clip.group, label: clip.label || clip.group, end: 0 }); }
    clip.videoTrack = lane;
    lanes[lane].end = clip.start + clip.frames;
    end = Math.max(end, clip.start + clip.frames);
    if (end > f.day) throw Error("素材跨午夜，請分時段處理。");
  }
  const start = sorted[0].start, length = end - start;
  if (length > f.nominal * 43200) throw Error("時間跨度超過 12 小時，請按拍攝時段分開選取。");
  const state = { projectID, sequenceID: "new", name: "將建立素材時間碼時間線", timebase: f.timebase,
    zero: String(BigInt(start) * BigInt(f.timebase)), end: String(BigInt(length) * BigInt(f.timebase)), display: f.display, markers: [] };
  const fingerprint = JSON.stringify([projectID, sorted.map(c => [c.id, c.name, c.path, c.start, c.frames, c.rate, c.hasAudio, c.group, c.videoTrack, c.sourceStartTicks, c.sourceDurationTicks, c.binPath, c.label])]);
  return { clips: sorted, lanes, state, fingerprint, plan: core.plan(data, state) };
}

// Walk the project tree once: selected parents include all descendants;
// selecting both a parent and child never imports the same project item twice.
async function collectSelection(ppro, project, selected) {
  if (!selected.length) throw Error("請先在 PR 專案面板選取最上層 Bin 或原始影片。");
  const wanted = new Set(selected.map(x => String(x.getId()))), visited = new Set(), found = new Set(), result = [];
  const camera = name => /^(?:[A-Za-z0-9]+[ _-]*機(?:位)?|機位[ _-]*[A-Za-z0-9]+|(?:cam|camera)[ _-]*[A-Za-z0-9]+|[A-Za-z0-9]+[ _-]*(?:cam|camera))$/i.test(name.trim());
  async function walk(item, chain, include) {
    const id = String(item.getId());
    if (chain.length > 64) throw Error("Bin 層級過深，請分批處理。");
    if (visited.has(id)) return;
    visited.add(id);
    if (visited.size > 20000) throw Error("專案項目過多，請分成較小專案。");
    if (wanted.has(id)) found.add(id);
    const active = include || wanted.has(id);
    let folder;
    try { folder = await ppro.FolderItem.cast(item); } catch (_) { folder = null; }
    if (folder) {
      const next = [...chain, { id, name: item.name }];
      for (const child of await folder.getItems()) await walk(child, next, active);
    } else if (active) {
      const candidates = chain.slice(1);
      const cameras = candidates.filter(b => camera(b.name));
      const owner = cameras[cameras.length - 1] || candidates[candidates.length - 1];
      result.push({item, group: owner ? "bin:" + owner.id : undefined, label: owner ? owner.name : undefined, binPath: chain});
      if (result.length > 2000) throw Error("選取 Bin 內超過 2,000 個項目，請分批處理。");
    }
  }
  await walk(await project.getRootItem(), [], false);
  if (found.size !== wanted.size) throw Error("選取項目已移動或無法讀取，請重新選取。");
  return result;
}

function createAssembly(ppro, markerHost) {
  const tt = ticks => ppro.TickTime.createWithTicks(String(ticks));
  function transaction(project, fn, name) {
    let ok = false;
    project.lockedAccess(() => { ok = project.executeTransaction(fn, name); });
    if (!ok) throw Error("PR 未完成「" + name + "」。");
  }
  async function inspect(raw) {
    const data = core.parse(raw), f = core.format(data.format);
    const project = await ppro.Project.getActiveProject();
    if (!project) throw Error("請先開啟 PR 專案。");
    const selection = await ppro.ProjectUtils.getSelection(project);
    const selected = selection ? await selection.getItems() : [];
    const entries = await collectSelection(ppro, project, selected);
    const clips = [], skipped = [];
    for (const entry of entries) {
      const {item} = entry;
      let clip;
      try { clip = await ppro.ClipProjectItem.cast(item); } catch (_) { clip = null; }
      if (!clip || await clip.isSequence() || await clip.isMergedClip() || await clip.isMulticamClip()) {
        skipped.push(item.name + "：略過非原始影片／序列"); continue;
      }
      if (await clip.isOffline()) throw Error(item.name + "：素材離線，請先重新連結。");
      const video = await clip.getComponentChain(ppro.Constants.MediaType.VIDEO);
      if (!video) { skipped.push(item.name + "：略過純音訊"); continue; }
      const path = await clip.getMediaFilePath();
      if (!path) throw Error(item.name + "：沒有來源路徑。");
      if (/\.(png|jpe?g|tiff?|psd|exr|gif|bmp|webp)$/i.test(path)) { skipped.push(item.name + "：略過圖片"); continue; }
      const interpretation = await clip.getFootageInterpretation();
      const rate = await interpretation.getFrameRate();
      const sf = sourceFormat(rate);
      // Adobe's project-column API exposes source times as tick strings, including on 25.6.
      const columns = JSON.parse(await ppro.Metadata.getProjectColumnsMetadata(item));
      const values = new Map(columns.map(c => [c.ColumnID, c.ColumnValue]));
      const startTicks = values.get("Column.Intrinsic.MediaStart");
      const endTicks = values.get("Column.Intrinsic.MediaEnd");
      if (!/^\d+$/.test(String(startTicks)) || !/^\d+$/.test(String(endTicks))) throw Error(item.name + "：PR 未提供可讀取的來源時間碼，請使用原始相機素材。");
      const sourceStart = roundTicks(startTicks, f.timebase);
      let duration = values.get("Column.Intrinsic.MediaDuration");
      if (!/^\d+$/.test(String(duration))) duration = String(BigInt(endTicks) - BigInt(startTicks));
      core.exactFrames(duration, sf.timebase, "來源素材長度");
      const frames = roundTicks(duration, f.timebase);
      const inPoint = await clip.getInPoint(ppro.Constants.MediaType.VIDEO);
      const outPoint = await clip.getOutPoint(ppro.Constants.MediaType.VIDEO);
      if (BigInt(inPoint.ticks) !== 0n || BigInt(outPoint.ticks) !== BigInt(duration)) throw Error(item.name + "：來源設有入出點或長度無法核對，請先清除素材入出點。");
      const hasAudio = !!(await clip.getComponentChain(ppro.Constants.MediaType.AUDIO));
      clips.push({ ...entry, item, clip, id: item.getId(), name: item.name, path, start: sourceStart, frames, rate, hasAudio, sourceStartTicks: String(startTicks), sourceDurationTicks: String(duration) });
    }
    const result = layout(data, clips, project.guid.toString());
    result.fingerprint = JSON.stringify([result.fingerprint, selected.map(x => String(x.getId())).sort(), skipped]);
    return { ...result, skipped, data, raw, project, mode: "new" };
  }
  async function trackItems(sequence, audio) {
    const count = await (audio ? sequence.getAudioTrackCount() : sequence.getVideoTrackCount());
    const result = [];
    for (let i = 0; i < count; i++) {
      const track = await (audio ? sequence.getAudioTrack(i) : sequence.getVideoTrack(i));
      for (const item of await track.getTrackItems(1, false)) {
        const source = await item.getProjectItem();
        result.push({ track: i, id: source.getId(), start: (await item.getStartTime()).ticks, duration: (await item.getDuration()).ticks,
          inPoint: (await item.getInPoint()).ticks });
      }
    }
    return result;
  }
  async function commit(review, raw) {
    if (!review || review.mode !== "new" || review.raw !== raw) throw Error("JSON 已變更，請重新檢查。");
    const fresh = await inspect(raw);
    if (fresh.fingerprint !== review.fingerprint) throw Error("選取素材或專案已變更，請重新檢查。");
    const { project, clips, state } = fresh;
    const previous = await project.getActiveSequence();
    let sequence = null;
    const name = "SetMark_" + fresh.data.title.slice(0, 60) + "_" + Date.now();
    try {
      // Starting from the first source preserves its video and audio sequence settings.
      sequence = await project.createSequenceFromMedia(name, [clips[0].clip], await project.getInsertionBin());
      if (!sequence) throw Error("PR 無法建立新時間線。");
      const settings = await sequence.getSettings();
      if (String(await sequence.getTimebase()) !== state.timebase) {
        if (typeof settings.setVideoFrameRate !== "function") throw Error("混合幀率自動建線需要 Premiere 26.2 以上。");
        const f = core.format(fresh.data.format);
        const frameRate = ppro.FrameRate.createWithValue(f.num / f.den);
        frameRate.ticksPerFrame = Number(state.timebase);
        if (!await settings.setVideoFrameRate(frameRate)) throw Error("PR 無法設定專案時間線影格率。");
      }
      const display = await sequence.getSequenceVideoTimeDisplayFormat();
      display.type = state.display;
      if (!await settings.setVideoDisplayFormat(display)) throw Error("PR 無法設定 DF／NDF 格式。");
      transaction(project, tx => {
        tx.addAction(sequence.createSetSettingsAction(settings));
        tx.addAction(sequence.createSetZeroPointAction(tt(state.zero)));
      }, "SetMark：設定素材起始時間碼");
      if (String(await sequence.getTimebase()) !== state.timebase) throw Error("新時間線影格率核對失敗。");
      const editor = ppro.SequenceEditor.getEditor(sequence);
      const audioStarts = new Map([[clips[0].id, 0]]);
      // Reserve fresh audio tracks per source: channel layouts may span multiple tracks.
      // Never insert another camera into a previously occupied audio track.
      for (const clip of clips.slice(1)) {
        const offset = BigInt(clip.start - clips[0].start) * BigInt(state.timebase);
        const audioTrack = await sequence.getAudioTrackCount();
        audioStarts.set(clip.id, audioTrack);
        transaction(project, tx => tx.addAction(editor.createInsertProjectItemAction(clip.item, tt(offset), clip.videoTrack, audioTrack, true)), "SetMark：依時間碼加入素材");
      }
      const videos = await trackItems(sequence, false), audios = await trackItems(sequence, true);
      if (videos.length !== clips.length) throw Error("新時間線的影片數量不符。");
      for (const clip of clips) {
        const expected = String(BigInt(clip.start - clips[0].start) * BigInt(state.timebase));
        const duration = String(BigInt(clip.frames) * BigInt(state.timebase));
        const matches = videos.filter(v => v.id === clip.id);
        if (matches.length !== 1 || matches[0].track !== clip.videoTrack || matches[0].start !== expected || matches[0].duration !== duration || BigInt(matches[0].inPoint) !== 0n) throw Error(clip.name + "：影片位置或長度核對失敗。");
        const audio = audios.filter(a => a.id === clip.id);
        if ((clip.hasAudio && !audio.length) || audio.some(a => a.track < audioStarts.get(clip.id) || a.start !== expected || a.duration !== clip.sourceDurationTicks || BigInt(a.inPoint) !== 0n)) throw Error(clip.name + "：音訊位置核對失敗。");
      }
      for (const a of audios) {
        if (!clips.some(c => c.id === a.id && c.hasAudio)) throw Error("出現未預期的音訊素材。");
        if (audios.some(b => b.id !== a.id && b.track === a.track)) throw Error("不同素材的音訊共用軌道，已停止。");
      }
      if (String((await sequence.getZeroPoint()).ticks) !== state.zero) throw Error("時間線起始時間碼核對失敗。");
      const activeProject = await ppro.Project.getActiveProject();
      if (!activeProject || activeProject.guid.toString() !== state.projectID) throw Error("操作途中切換了專案，已停止。");
      if (!await project.openSequence(sequence) || !await project.setActiveSequence(sequence)) throw Error("無法開啟新時間線。");
      const markerReview = await markerHost.preview(raw);
      if (markerReview.state.sequenceID !== sequence.guid.toString()) throw Error("目前時間線已切換，已停止。");
      // A native duration difference must not silently produce a different marker plan.
      if (JSON.stringify(markerReview.plan.additions) !== JSON.stringify(fresh.plan.additions)) throw Error("時間線範圍與預覽不同，已停止。");
      const count = await markerHost.commit(markerReview, raw, true);
      return { count, name };
    } catch (error) {
      let removed = true;
      if (sequence) {
        try { removed = await project.deleteSequence(sequence); } catch (_) { removed = false; }
        try { if (previous) { await project.openSequence(previous); await project.setActiveSequence(previous); } } catch (_) { /* report original failure */ }
      }
      throw Error((error.message || String(error)) + (removed ? "" : "\n無法清理本次新時間線「" + name + "」，請檢查後手動刪除。"));
    }
  }
  return { preview: inspect, commit };
}
module.exports = { layout, cameraGroup, createAssembly, sourceFormat, roundTicks, collectSelection };
