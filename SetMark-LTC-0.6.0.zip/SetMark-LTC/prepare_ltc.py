"""SetMark LTC preparation. Standard-library PCM WAV decoder; originals are read-only."""
import argparse, hashlib, json, math, struct, wave
from fractions import Fraction
from pathlib import Path
TICKS = 254016000000
RATES = {'23.976': (24000,1001,24,False), '24':(24,1,24,False), '25':(25,1,25,False),
 '29.97 DF':(30000,1001,30,True), '29.97 NDF':(30000,1001,30,False), '30':(30,1,30,False),
 '50':(25,1,25,False), '59.94 DF':(30000,1001,30,True), '59.94 NDF':(30000,1001,30,False), '60':(30,1,30,False)}
SYNC = [int(x) for x in '0011111111111101']

def ticks(seconds): return round(seconds * TICKS)
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def pcm(raw,width):
 if width==1: return [x-128 for x in raw]
 if width==2: return [x[0] for x in struct.iter_unpack('<h',raw)]
 if width==4: return [x[0] for x in struct.iter_unpack('<i',raw)]
 if width==3: return [int.from_bytes(raw[i:i+3],'little',signed=True) for i in range(0,len(raw),3)]
 raise ValueError('只支援 8/16/24/32-bit PCM WAV；浮點、RF64 或壓縮音訊請先轉成 PCM。')

def frame_number(bits,nominal,drop):
 def bcd(pos,n): return sum(bits[pos+i]<<i for i in range(n))
 fu,ft,su,st,mu,mt,hu,ht=(bcd(p,n) for p,n in [(0,4),(8,2),(16,4),(24,3),(32,4),(40,3),(48,4),(56,2)])
 h,m,s,f=hu+ht*10,mu+mt*10,su+st*10,fu+ft*10
 if any(x>9 for x in [fu,su,mu,hu]) or h>=24 or m>=60 or s>=60 or f>=nominal: return None
 if bool(bits[10])!=drop: return None
 if drop and (nominal!=30 or (m%10 and s==0 and f<2)): return None
 minutes=h*60+m
 return ((h*3600+m*60+s)*nominal+f)-(2*(minutes-minutes//10) if drop else 0)

def decode(samples,sr,fmt):
 """Decode forward biphase-mark transitions, retaining frame-start sample offsets."""
 num,den,nominal,drop=RATES[fmt]; half=sr*den/(num*160)
 if not samples: return []
 peak=max(abs(x) for x in samples)
 if peak<8: return []
 threshold=peak*.12; edges=[]; polarity=0
 for i,x in enumerate(samples):
  state=1 if x>threshold else -1 if x < -threshold else polarity
  if polarity and state!=polarity: edges.append(i)
  polarity=state
 bits=[]; starts=[]; pending=None; result=[]
 for a,b in zip(edges,edges[1:]):
  ratio=(b-a)/half
  if .65<=ratio<=1.35:
   if pending is None:
    pending=a; continue
   else: bits.append(1); starts.append(pending); pending=None
  elif 1.65<=ratio<=2.35:
   if pending is not None: bits=[]; starts=[]; pending=None
   bits.append(0); starts.append(a)
  else: bits=[]; starts=[]; pending=None
  if len(bits)>=80 and bits[-16:]==SYNC:
   value=frame_number(bits[-80:],nominal,drop)
   if value is not None: result.append((value,starts[-80]))
  if len(bits)>160: bits=bits[-80:]; starts=starts[-80:]
 return result

def scan(path,fmt):
 """Require coherent LTC in every 30-second checkpoint, including head and tail."""
 with wave.open(str(path),'rb') as w:
  channels,width,sr,n=w.getnchannels(),w.getsampwidth(),w.getframerate(),w.getnframes()
  if w.getcomptype()!='NONE' or sr<16000 or channels>32: raise ValueError('不支援的 WAV 格式。')
  window=min(n,sr*3)
  if window<sr: raise ValueError('錄音至少需要 1 秒，才能可靠辨識 LTC。')
  positions=sorted(set([0,max(0,n-window)]+list(range(30*sr,max(0,n-window),30*sr))))
  candidates={c:[] for c in range(channels)}
  num,den,_,_=RATES[fmt]; rate=Fraction(num,den)
  for pos in positions:
   w.setpos(pos); values=pcm(w.readframes(window),width)
   for c in list(candidates):
    frames=decode(values[c::channels],sr,fmt)
    # Consecutive 12+ frame runs prevent noise/speech being treated as a clock.
    runs=[]; run=[]
    for frame,sample in frames:
     if run and (frame!=run[-1][0]+1 or abs((sample-run[-1][1])-sr/float(rate))>sr/float(rate)*.1):
      if len(run)>=12:runs.extend(run)
      run=[]
     run.append((frame,sample))
    if len(run)>=12:runs.extend(run)
    if not runs: del candidates[c]; continue
    candidates[c].extend(Fraction(f,1)/rate-Fraction(pos+s,sr) for f,s in runs)
  if not candidates:return None
  if len(candidates)>1: raise ValueError('多個聲道都有 LTC，請先明確保留一條時間碼軌。')
  c,offsets=next(iter(candidates.items()))
  spread=max(offsets)-min(offsets)
  if spread>Fraction(1,2)/rate: raise ValueError('LTC 前後不連續或漂移超過半格；請分段或另外做漂移校正。')
  offsets.sort(); start=offsets[len(offsets)//2]
  if start<0 or start+Fraction(n,sr)>=86400: raise ValueError('跨午夜錄音請分日處理。')
  return dict(channel=c,channels=channels,width=width,sampleRate=sr,sampleFrames=n,start=start,spread=float(spread),checkpoints=len(positions))

def write_channels(source,dest,keep):
 with wave.open(str(source),'rb') as src, wave.open(str(dest),'wb') as out:
  channels,width=src.getnchannels(),src.getsampwidth()
  out.setnchannels(len(keep));out.setsampwidth(width);out.setframerate(src.getframerate())
  while True:
   data=src.readframes(16384)
   if not data:break
   stride=channels*width
   out.writeframesraw(b''.join(data[i+c*width:i+(c+1)*width] for i in range(0,len(data),stride) for c in keep))

def prepare(root,shoot_path,out,groups_path=None):
 root=Path(root).resolve();out=Path(out).resolve()
 if out.exists(): raise ValueError('輸出資料夾已存在；請選新資料夾，避免覆寫。')
 shoot=json.loads(Path(shoot_path).read_text(encoding='utf-8-sig'))
 if shoot.get('format') not in RATES or not isinstance(shoot.get('marks'),list) or not shoot.get('id'): raise ValueError('請選 SetMark 專案 JSON。')
 files=sorted(p for p in root.rglob('*') if p.suffix.lower()=='.wav' and p.is_file())
 if len(files)>2000:raise ValueError('超過 2,000 個 WAV，請分批處理。')
 decoded={};report=[]
 for path in files:
  print('掃描 '+str(path.relative_to(root)),flush=True)
  try:
   info=scan(path,shoot['format'])
   if info:decoded[path]=info
   else:report.append({'file':str(path),'status':'未辨識到連續 LTC，未自動配對'})
  except (ValueError,wave.Error,EOFError) as exc:
   report.append({'file':str(path),'status':str(exc)})
 groups=json.loads(Path(groups_path).read_text(encoding='utf-8')) if groups_path else []
 if not isinstance(groups,list):raise ValueError('分組檔必須是清單。')
 assignments={}
 for group in groups:
  if group.get('confirmedSameStart') is not True:raise ValueError('每組必須確認 confirmedSameStart，不能依檔名猜起點。')
  ref=(root/group['ltc']).resolve()
  if ref not in decoded:raise ValueError('指定 LTC 參考檔未通過解碼：'+str(ref))
  for name in group['audio']:
   p=(root/name).resolve()
   if p not in files or p in decoded or p in assignments:raise ValueError('分組重複、來源不存在或已含 LTC：'+str(p))
   with wave.open(str(p),'rb') as w:
    info=decoded[ref]
    if w.getframerate()!=info['sampleRate'] or w.getnframes()!=info['sampleFrames']:raise ValueError('配對檔長度／取樣率不同，拒絕猜測：'+str(p))
    assignments[p]=dict(info,channel=None,channels=w.getnchannels(),width=w.getsampwidth())
 if not decoded:raise ValueError('沒有可驗證的 LTC。請核對專案時間碼格式、音量及錄音是否持續。')
 out.mkdir(parents=True);audio=out/'audio';audio.mkdir();entries=[]
 for path,info in list(decoded.items())+list(assignments.items()):
  keep=[c for c in range(info['channels']) if c!=info['channel']]
  if not keep:
   report.append({'file':str(path),'status':'純 LTC 參考軌，不加入可聽音軌'});continue
  target=audio/(hashlib.sha256(str(path).encode()).hexdigest()[:12]+'_'+path.stem+'.wav')
  write_channels(path,target,keep)
  entries.append(dict(path=str(target),source=str(path),startTicks=str(ticks(info['start'])),durationTicks=str(ticks(Fraction(info['sampleFrames'],info['sampleRate']))),
   sampleRate=info['sampleRate'],sampleFrames=info['sampleFrames'],channels=len(keep),sha256=digest(target),ltcChannel=None if info['channel'] is None else info['channel']+1))
  report.append({'file':str(path),'status':'已輸出收音副本','LTC聲道':info['channel'],'checkpoints':info['checkpoints'],'offsetSpreadSeconds':info['spread']})
 if not entries:raise ValueError('只找到純 LTC；請用分組檔明確指定同起點收音檔。掃描結果在終端；原檔未改動。')
 shoot['ltcAudio']={'version':1,'format':shoot['format'],'clips':entries}
 (out/'SetMark-LTC.json').write_text(json.dumps(shoot,ensure_ascii=False,indent=2),encoding='utf-8')
 (out/'scan-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 return shoot

def main():
 parser=argparse.ArgumentParser(description='SetMark LTC：解碼 WAV 並產生 PR / Resolve 同步資料')
 parser.add_argument('--audio');parser.add_argument('--json');parser.add_argument('--output');parser.add_argument('--groups')
 args=parser.parse_args()
 if not args.audio:
  import tkinter as tk
  from tkinter import filedialog,messagebox
  root=tk.Tk();root.withdraw()
  args.audio=filedialog.askdirectory(title='選擇錄音資料夾')
  if not args.audio:return
  args.json=filedialog.askopenfilename(title='選 SetMark JSON',filetypes=[('JSON','*.json')])
  if not args.json:return
  parent=filedialog.askdirectory(title='選擇輸出位置（會建立 SetMark-LTC 子資料夾）')
  if not parent:return
  args.output=str(Path(parent)/'SetMark-LTC')
  if messagebox.askyesno('分開錄音軌','是否已有分組 JSON？分開 WAV 必須明確指定同一起點。'):
   args.groups=filedialog.askopenfilename(title='選分組 JSON',filetypes=[('JSON','*.json')]) or None
  try:
   prepare(args.audio,args.json,args.output,args.groups)
   messagebox.showinfo('完成','把輸出 audio 資料夾匯入 PR / Resolve 的最上層 Bin，再選 SetMark-LTC.json 建線。請查看 scan-report.json 的略過項目。')
  except Exception as exc:messagebox.showerror('未完成',str(exc))
 else:
  if not args.json or not args.output:parser.error('需要 --json 和 --output')
  prepare(args.audio,args.json,args.output,args.groups)
if __name__=='__main__':main()
