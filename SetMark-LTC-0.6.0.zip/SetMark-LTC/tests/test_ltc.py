import importlib.util,json,math,random,struct,tempfile,unittest,wave
from pathlib import Path
spec=importlib.util.spec_from_file_location('ltc',Path(__file__).parents[1]/'prepare_ltc.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def signal(start=3600*25,count=40,rate=25,sr=48000,drop=False,invert=False):
 # Independent forward LTC encoder: BCD fields + sync, biphase-mark transitions.
 bits=[]
 for frame in range(start,start+count):
  nominal=round(rate);sec,ff=divmod(frame,nominal);minutes,ss=divmod(sec,60);hh,mm=divmod(minutes,60)
  b=[0]*80
  for pos,val,n in [(0,ff%10,4),(8,ff//10,2),(16,ss%10,4),(24,ss//10,3),(32,mm%10,4),(40,mm//10,3),(48,hh%10,4),(56,hh//10,2)]:
   for i in range(n):b[pos+i]=(val>>i)&1
  b[10]=int(drop);b[64:]=[0,0]+[1]*12+[0,1];bits.extend(b)
 edges=[]
 for i,bit in enumerate(bits):
  edges.append(round(i*sr/(rate*80)))
  if bit:edges.append(round((i+.5)*sr/(rate*80)))
 edges=set(edges);v=15000*(-1 if invert else 1);result=[]
 for i in range(round(len(bits)*sr/(rate*80))):
  if i in edges:v=-v
  result.append(v)
 return result

def wav(path,channels,width=2):
 with wave.open(str(path),'wb') as w:
  w.setnchannels(len(channels));w.setsampwidth(width);w.setframerate(48000)
  w.writeframes(b''.join(int(v).to_bytes(width,'little',signed=True) for row in zip(*channels) for v in row))

class LTC(unittest.TestCase):
 def test_decode_rates_polarity_and_offset(self):
  for fmt in ['24','25','30','23.976','29.97 NDF','29.97 DF','59.94 DF']:
   n,d,nom,drop=m.RATES[fmt];rate=n/d
   for polarity in [False,True]:
    src=[0]*123+signal(start=nom*3600,count=40,rate=rate,drop=drop,invert=polarity)
    decoded=m.decode(src,48000,fmt)
    self.assertGreater(len(decoded),30)
    frame,sample=decoded[0]
    self.assertLess(abs(sample-(123+(frame-(nom*3600-108 if drop else nom*3600))*48000/rate)),2)
 def test_noise_and_wrong_format_not_detected(self):
  random.seed(5)
  self.assertEqual(m.decode([random.randrange(-20000,20000) for _ in range(48000)],48000,'25'),[])
  self.assertEqual(m.decode(signal(drop=False,rate=30),48000,'29.97 DF'),[])
 def test_prepare_keeps_original_removes_ltc_and_transfers_explicit_group(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);audio=root/'source';audio.mkdir();src=signal();voice=[1234]*len(src)
   wav(audio/'stereo.wav',[voice,src],3);wav(audio/'ref.wav',[src]);wav(audio/'mic.wav',[voice])
   original=m.digest(audio/'stereo.wav')
   shoot=root/'shoot.json';shoot.write_text(json.dumps({'id':'s','format':'25','marks':[]}))
   groups=root/'groups.json';groups.write_text(json.dumps([{'ltc':'ref.wav','audio':['mic.wav'],'confirmedSameStart':True}]))
   out=m.prepare(audio,shoot,root/'out',groups)
   self.assertEqual(len(out['ltcAudio']['clips']),2);self.assertEqual(m.digest(audio/'stereo.wav'),original)
   for entry in out['ltcAudio']['clips']:
    with wave.open(entry['path'],'rb') as w:
     self.assertEqual(w.getnchannels(),1);self.assertEqual(w.getnframes(),len(src))
     self.assertEqual(m.pcm(w.readframes(20),w.getsampwidth()),[1234]*20)
 def test_unconfirmed_groups_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);wav(r/'ref.wav',[signal()]);s=r/'s.json';s.write_text(json.dumps({'id':'s','format':'25','marks':[]}));g=r/'g.json';g.write_text('[{"ltc":"ref.wav","audio":[]}]')
   with self.assertRaisesRegex(ValueError,'confirmedSameStart'):m.prepare(r,s,r/'out',g)
 def test_drift_and_multiple_ltc_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'x.wav';src=signal(count=100)
   wav(p,[src,src])
   with self.assertRaisesRegex(ValueError,'多個'):m.scan(p,'25')
   broken=signal(count=50)+signal(start=3600*25+60,count=50);wav(p,[broken])
   with self.assertRaisesRegex(ValueError,'漂移'):m.scan(p,'25')
 def test_pcm_widths(self):
  for width in [2,3,4]:
   self.assertEqual(m.pcm(b''.join(x.to_bytes(width,'little',signed=True) for x in [-500,0,500]),width),[-500,0,500])
if __name__=='__main__':unittest.main()
