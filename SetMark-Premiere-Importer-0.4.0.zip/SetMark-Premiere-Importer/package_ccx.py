"""Build and structurally verify a direct-distribution UXP CCX (standard ZIP).

Run with Python 3. This does not substitute for Creative Cloud installation QA.
"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parent
PLUGIN = ROOT / "plugin"
manifest = json.loads((PLUGIN / "manifest.json").read_text(encoding="utf-8"))
assert manifest["manifestVersion"] == 5
assert isinstance(manifest["host"], dict)
assert manifest["host"]["app"] == "premierepro"
assert manifest["host"]["minVersion"] == "26.2.0"
assert re.fullmatch(r"[A-Za-z0-9._-]+", manifest["id"])
assert re.fullmatch(r"\d+\.\d+\.\d+", manifest["version"])
assert any(e["type"] == "panel" for e in manifest["entrypoints"])
assert manifest["requiredPermissions"] == {"localFileSystem": "request"}
expected = {"manifest.json", "index.html", "main.js", "core.js", "host.js", "assembly.js", "style.css"}
files = {p.name: p for p in PLUGIN.iterdir() if p.is_file() and not p.name.startswith(".")}
assert set(files) == expected, "Review unexpected or missing plugin files before packaging"
assert manifest["main"] in files
assert not any(p.is_symlink() for p in files.values())
ccx = ROOT / ("SetMark-" + manifest["version"] + ".ccx")
with zipfile.ZipFile(ccx, "w", zipfile.ZIP_DEFLATED) as archive:
    for name, source in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 9, 15, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, source.read_bytes())
with zipfile.ZipFile(ccx) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == expected
    for name, source in files.items():
        assert archive.read(name) == source.read_bytes(), name
digest = hashlib.sha256(ccx.read_bytes()).hexdigest()
(ROOT / "CCX-SHA256.txt").write_text(f"{digest}  {ccx.name}\n", encoding="utf-8")
print(f"Created {ccx.name}: {ccx.stat().st_size} bytes; {len(expected)} root files verified against source.")
print("Creative Cloud installation and Premiere runtime verification remain pending.")
