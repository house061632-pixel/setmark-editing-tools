"use strict";
const core = require("./core.js");
function createHost(ppro) {
  function markers(owner) {
    return owner.getMarkers().map(m => ({ ticks: m.getStart().ticks, comments: m.getComments(), name: m.getName() }));
  }
  async function snapshot() {
    const project = await ppro.Project.getActiveProject();
    if (!project) throw Error("請先開啟 Premiere 專案。");
    const sequence = await project.getActiveSequence();
    if (!sequence) throw Error("請先在 Premiere 點選要加入標記的時間線。");
    const timebase = await sequence.getTimebase();
    const zero = await sequence.getZeroPoint(), end = await sequence.getEndTime();
    const display = await sequence.getSequenceVideoTimeDisplayFormat();
    const owner = await ppro.Markers.getMarkers(sequence);
    return { project, owner, state: { projectID: project.guid.toString(), sequenceID: sequence.guid.toString(),
      name: sequence.name, timebase: String(timebase), zero: zero.ticks, end: end.ticks,
      display: display.type, markers: markers(owner) } };
  }
  async function preview(raw) {
    const data = core.parse(raw), current = await snapshot();
    return { data, raw, state: current.state, fingerprint: core.fingerprint(current.state), plan: core.plan(data, current.state) };
  }
  async function commit(review, raw, aligned) {
    if (!aligned) throw Error("請先確認時間線和素材的時間碼已對齊。");
    if (!review || raw !== review.raw) throw Error("JSON 已改變，請重新檢查標記。");
    const current = await snapshot();
    if (core.fingerprint(current.state) !== review.fingerprint) throw Error("時間線或標記已改變，請重新檢查標記。");
    const planned = core.plan(core.parse(raw), current.state);
    if (!planned.additions.length) return 0;
    let success = false;
    current.project.lockedAccess(() => {
      current.state.markers = markers(current.owner);
      if (core.fingerprint(current.state) !== review.fingerprint) throw Error("標記已改變，請重新檢查標記。");
      success = current.project.executeTransaction(transaction => {
        for (const m of planned.additions) {
          transaction.addAction(current.owner.createAddMarkerAction(m.name, ppro.Marker.MARKER_TYPE_COMMENT,
            ppro.TickTime.createWithTicks(m.ticks), ppro.TickTime.createWithTicks("0"), m.comments));
        }
      }, "SetMark：匯入 JSON 標記");
    });
    if (!success) throw Error("Premiere 未完成匯入。請重新檢查標記後再試。");
    return planned.additions.length;
  }
  return { preview, commit };
}
module.exports = { createHost };
