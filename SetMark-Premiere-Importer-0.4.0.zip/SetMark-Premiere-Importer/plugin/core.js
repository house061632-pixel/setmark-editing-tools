"use strict";

// No host calls here: frame calculations can be tested without Premiere.
const TICKS = 254016000000n;
const FORMATS = {
  "23.976": [24, 24000, 1001, 0, 110], "24": [24, 24, 1, 0, 100],
  "25": [25, 25, 1, 0, 101], "29.97 NDF": [30, 30000, 1001, 0, 103],
  "29.97 DF": [30, 30000, 1001, 2, 102], "30": [30, 30, 1, 0, 104],
  "50": [50, 50, 1, 0, 105], "59.94 NDF": [60, 60000, 1001, 0, 107],
  "59.94 DF": [60, 60000, 1001, 4, 106], "60": [60, 60, 1, 0, 108]
};
function format(name) {
  if (!Object.prototype.hasOwnProperty.call(FORMATS, name)) throw Error("不支援的時間碼格式。請重新從 SetMark 匯出 JSON。");
  const [nominal, num, den, drop, display] = FORMATS[name];
  return { nominal, num, den, drop, display, day: nominal * 86400 - drop * 1296,
    timebase: String(TICKS * BigInt(den) / BigInt(num)) };
}
function integer(value, label) {
  if (!Number.isSafeInteger(value)) throw Error(label + "必須是有效的整數。");
  return value;
}
function text(value, label, max = 20000) {
  if (typeof value !== "string" || value.length > max) throw Error(label + "格式不正確或過長。");
  return value;
}
function parse(raw) {
  if (typeof raw !== "string" || raw.length > 20 * 1024 * 1024) throw Error("JSON 超過 20 MB 或無法讀取。");
  let data;
  try { data = JSON.parse(raw.replace(/^\uFEFF/, "")); } catch (_) { throw Error("這不是有效的 JSON 檔案。"); }
  if (!data || typeof data !== "object" || Array.isArray(data)) throw Error("請選擇 SetMark 匯出的專案 JSON。");
  if (data.isTest) throw Error("這是測試時間碼專案，不能匯入正式時間線。");
  const f = format(data.format);
  text(data.id, "專案識別碼", 500);
  if (!data.id) throw Error("缺少專案識別碼。");
  if (!Array.isArray(data.marks) || data.marks.length > 100000) throw Error("標記清單無效或超過 100,000 筆。");
  const lookback = data.lookback === undefined ? 0 : data.lookback;
  if (typeof lookback !== "number" || !Number.isFinite(lookback) || lookback < 0 || lookback > 86400) throw Error("往前保留秒數不正確。");
  const fallback = Math.round(lookback * f.num / f.den);
  const ids = new Set();
  const marks = data.marks.map(m => {
    if (!m || typeof m !== "object") throw Error("標記資料不完整。");
    text(m.id, "標記識別碼", 500);
    if (!m.id || ids.has(m.id)) throw Error("標記識別碼缺少或重複。");
    ids.add(m.id);
    const frame = integer(m.frame, "標記影格");
    const compensation = integer(m.lookbackFrames === undefined ? fallback : m.lookbackFrames, "往前保留影格");
    if (compensation < 0 || compensation > f.day || !Number.isSafeInteger(frame + compensation)) throw Error("標記時間超出支援範圍。");
    return { id: m.id, frame, compensation, tag: text(m.tag, "標記名稱", 500),
      note: text(m.note === undefined ? "" : m.note, "備註"),
      author: text(m.author === undefined ? "" : m.author, "姓名", 500) };
  });
  return { id: data.id, title: text(data.title === undefined ? "未命名專案" : data.title, "專案名稱", 1000), format: data.format, marks };
}
function mod(n, d) { return ((n % d) + d) % d; }
function timecode(frame, name) {
  const f = format(name);
  let label = mod(frame, f.day);
  if (f.drop) {
    const ten = f.nominal * 600 - f.drop * 9;
    const minute = f.nominal * 60 - f.drop;
    const blocks = Math.floor(label / ten), rest = label % ten;
    label += f.drop * 9 * blocks + f.drop * Math.max(0, Math.floor((rest - f.drop) / minute));
  }
  const ff = label % f.nominal;
  const seconds = Math.floor(label / f.nominal);
  return [Math.floor(seconds / 3600), Math.floor(seconds / 60) % 60, seconds % 60].map(x => String(x).padStart(2, "0")).join(":") + (f.drop ? ";" : ":") + String(ff).padStart(2, "0");
}
function exactFrames(ticks, base, label) {
  if (!/^-?\d+$/.test(String(ticks)) || !/^\d+$/.test(String(base)) || BigInt(base) <= 0n) throw Error(label + "無法讀取。");
  const t = BigInt(ticks), b = BigInt(base);
  if (t % b !== 0n) throw Error(label + "沒有對齊完整影格。");
  return integer(Number(t / b), label);
}
const PREFIX = "[SetMark:v1:";
function identity(project, ids) { return PREFIX + encodeURIComponent(JSON.stringify([project, ids.slice().sort()])) + "]"; }
function readIdentity(comments) {
  const last = String(comments).split("\n").pop();
  if (!last.startsWith(PREFIX) || !last.endsWith("]")) return null;
  try {
    const value = JSON.parse(decodeURIComponent(last.slice(PREFIX.length, -1)));
    return Array.isArray(value) && typeof value[0] === "string" && Array.isArray(value[1]) && value[1].every(x => typeof x === "string") ? value : null;
  } catch (_) { return null; }
}
function plan(data, state) {
  const f = format(data.format);
  if (String(state.timebase) !== f.timebase) throw Error("時間線影格率與 JSON 的 " + data.format + " 不一致。請先使用相同影格率的時間線。");
  if (state.display !== f.display) throw Error("時間線的時間碼顯示格式與 JSON 不一致。請將序列顯示格式設為 " + data.format + "（包括 DF／NDF）。");
  const start = exactFrames(state.zero, state.timebase, "時間線起始時間");
  if (!/^\d+$/.test(String(state.end))) throw Error("時間線長度無法讀取。");
  // Audio can end between video frames; include a frame whose start precedes the end.
  const base = BigInt(state.timebase);
  const length = integer(Number((BigInt(state.end) + base - 1n) / base), "時間線長度");
  if (length <= 0 || length >= f.day) throw Error("請開啟有素材、且長度不到 24 小時的時間線。");
  const occupied = new Set(), imported = new Set();
  for (const marker of state.markers) {
    // A marker within the frame also occupies that frame (e.g. audio-unit edits).
    occupied.add(Number(BigInt(marker.ticks) / BigInt(state.timebase)));
    const known = readIdentity(marker.comments);
    if (known && known[0] === data.id) for (const id of known[1]) imported.add(id);
  }
  let outside = 0, repeated = 0, conflict = 0;
  const groups = new Map();
  for (const m of data.marks) {
    if (imported.has(m.id)) { repeated++; continue; }
    const relative = mod(m.frame + m.compensation - start, f.day);
    if (relative >= length) { outside++; continue; }
    if (occupied.has(relative)) { conflict++; continue; }
    if (!groups.has(relative)) groups.set(relative, []);
    groups.get(relative).push(m);
  }
  const additions = Array.from(groups, ([frame, marks]) => ({ frame,
    ticks: String(BigInt(frame) * BigInt(state.timebase)),
    tc: timecode(start + frame, data.format),
    name: [...new Set(marks.map(m => m.tag))].join(" / "),
    comments: marks.map(m => (m.author ? m.author + " · " : "") + m.tag + (m.note ? "：" + m.note : "")).join("\n") + "\n\n" + identity(data.id, marks.map(m => m.id))
  })).sort((a, b) => a.frame - b.frame);
  return { additions, outside, repeated, conflict, startTC: timecode(start, data.format), total: data.marks.length };
}
function fingerprint(state) {
  return JSON.stringify([state.projectID, state.sequenceID, state.timebase, state.display, state.zero, state.end,
    state.markers.map(m => [m.ticks, m.comments, m.name]).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)))]);
}
module.exports = { FORMATS, format, parse, timecode, exactFrames, identity, readIdentity, plan, fingerprint };
