"use strict";
const test = require("node:test"), assert = require("node:assert/strict"), vm = require("node:vm"), fs = require("node:fs"), path = require("node:path");
const script = fs.readFileSync(path.join(__dirname, "../plugin/main.js"), "utf8");
function fixture() {
  const ids = ["choose", "preview", "aligned", "newSequence", "import", "hint", "filename", "status", "report"];
  const elements = Object.fromEntries(ids.map(id => [id, { disabled: false, checked: false, value: "", textContent: "", handlers: {},
    addEventListener(event, fn) { this.handlers[event] = fn; } }]));
  let picked = { name: "marks.json", getMetadata: async () => ({ size: 100 }), read: async () => "original" }, calls = 0, fail = false;
  const host = { preview: async raw => { if (fail) throw Error("格式不一致"); return { raw, state: { name: "timeline" }, data: { title: "project", format: "29.97 DF" },
    plan: { additions: [{ tc: "00:00:03;00", name: "爆笑", comments: "A 組 · 爆笑" }], repeated: 0, outside: 0, conflict: 0, startTC: "00:00:00;00" } }; },
    commit: async () => { calls++; return 1; } };
  vm.runInNewContext(script, { document: { getElementById: id => elements[id] }, require: name => {
    if (name === "uxp") return { storage: { localFileSystem: { getFileForOpening: async () => picked } } };
    if (name === "./host.js") return { createHost: () => host };
    if (name === "./assembly.js") return { createAssembly: () => ({ preview: async raw => ({ ...await host.preview(raw), mode: "new", clips: [{}], lanes: [{group:"A機"}] }), commit: async () => { calls++; return { count: 1, name: "new timeline" }; } }) };
    if (name === "premierepro") return {};
    throw Error(name);
  } });
  return { e: elements, click: id => elements[id].handlers.click(), cancel: () => { picked = null; }, fail: () => { fail = true; }, calls: () => calls };
}
test("UI requires preview and alignment; completed import cannot repeat with old preview", async () => {
  const f = fixture();
  assert.equal(f.e.import.disabled, true); assert.equal(f.e.preview.disabled, true);
  await f.click("choose"); assert.equal(f.e.preview.disabled, false);
  await f.click("preview"); assert.equal(f.e.import.disabled, true); assert.match(f.e.hint.textContent, /勾選/);
  f.e.aligned.checked = true; f.e.aligned.handlers.change(); assert.equal(f.e.import.disabled, false);
  await f.click("import"); assert.equal(f.calls(), 1); assert.equal(f.e.import.disabled, true);
  assert.match(f.e.status.textContent, /已新增 1/);
});
test("picker cancellation performs no import; preview errors disable import", async () => {
  const f = fixture(); f.cancel(); await f.click("choose"); assert.equal(f.calls(), 0); assert.equal(f.e.preview.disabled, true);
  const g = fixture(); await g.click("choose"); g.fail(); await g.click("preview");
  assert.equal(g.e.import.disabled, true); assert.match(g.e.status.textContent, /格式不一致/);
});
test("new sequence mode bypasses existing-timeline alignment and resets after creation", async () => {
  const f = fixture(); await f.click("choose");
  f.e.newSequence.checked = true; f.e.newSequence.handlers.change();
  assert.equal(f.e.aligned.disabled, true); assert.equal(f.e.import.disabled, true);
  await f.click("preview"); assert.equal(f.e.import.disabled, false);
  await f.click("import"); assert.match(f.e.status.textContent, /已建立/);
  assert.equal(f.e.newSequence.checked, false); assert.equal(f.e.import.disabled, true);
});
