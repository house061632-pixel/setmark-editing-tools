"use strict";
const test = require("node:test"), assert = require("node:assert/strict");
const c = require("../plugin/core.js"), { createHost } = require("../plugin/host.js");
function shoot(marks, extra = {}) { return JSON.stringify({ id: "project", title: "綜藝測試", format: "29.97 DF", lookback: 5, marks, ...extra }); }
function mark(id, frame, extra = {}) { return { id, frame, tag: "爆笑", note: "哈哈", author: "A 組", ...extra }; }
function state(name = "29.97 DF", start = 0, length = 18000) {
  const f = c.format(name), ticks = n => String(BigInt(n) * BigInt(f.timebase));
  return { projectID: "p", sequenceID: "s", name: "Sequence", timebase: f.timebase, display: f.display,
    zero: ticks(start), end: ticks(length), markers: [] };
}
test("all supported rates: exact ticks, nonzero sequence start, per-marker compensation", () => {
  for (const name of Object.keys(c.FORMATS)) {
    const data = c.parse(shoot([mark("a", 1000, { lookbackFrames: 150 })], { format: name }));
    const result = c.plan(data, state(name, 900));
    assert.equal(result.additions[0].frame, 250);
    assert.equal(result.additions[0].ticks, String(250n * BigInt(c.format(name).timebase)));
  }
});
test("mixed 5s, 3s, zero and legacy lookback all restore button-press frames", () => {
  const result = c.plan(c.parse(shoot([
    mark("a", 1000, { lookbackFrames: 150 }), mark("b", 2000, { lookbackFrames: 90 }),
    mark("c", 3000, { lookbackFrames: 0 }), mark("d", 4000)
  ])), state());
  assert.deepEqual(result.additions.map(m => m.frame), [1150, 2090, 3000, 4150]);
  assert.match(result.additions[0].comments, /A 組 · 爆笑：哈哈/);
});
test("DF minute, ten-minute, hour and midnight boundaries", () => {
  for (const [name, scale] of [["29.97 DF", 1], ["59.94 DF", 2]]) {
    assert.equal(c.timecode(1800 * scale, name), "00:01:00;" + String(2 * scale).padStart(2, "0"));
    assert.equal(c.timecode(17982 * scale, name), "00:10:00;00");
    assert.equal(c.timecode(107892 * scale, name), "01:00:00;00");
    assert.equal(c.timecode(c.format(name).day, name), "00:00:00;00");
    assert.equal(c.timecode(-1, name), "23:59:59;" + (30 * scale - 1));
    const result = c.plan(c.parse(shoot([mark("a", -30, { lookbackFrames: 40 })], { format: name })), state(name, c.format(name).day - 100, 300));
    assert.equal(result.additions[0].frame, 110);
  }
});
test("whole-day timecode labels monotonically follow DF labels", () => {
  // Every minute boundary is checked, including hour transitions.
  for (let minute = 0; minute < 1440; minute++) {
    const dropped = 2 * (minute - Math.floor(minute / 10));
    const first = minute * 1800 - dropped + (minute % 10 ? 2 : 0);
    assert.equal(c.timecode(first, "29.97 DF"),
      String(Math.floor(minute / 60)).padStart(2, "0") + ":" + String(minute % 60).padStart(2, "0") + ":00;" + (minute % 10 ? "02" : "00"));
  }
});
test("same-frame grouping; repeats including moved markers; conflicts and outside", () => {
  const data = c.parse(shoot([mark("a", 100), mark("b", 100, { author: "B 組", tag: "金句" }), mark("c", 200), mark("d", 500)], { lookback: 0 }));
  const s = state("29.97 DF", 0, 400);
  s.markers = [{ ticks: String(200n * BigInt(s.timebase)), name: "人工標記", comments: "keep" }];
  const result = c.plan(data, s);
  assert.equal(result.additions.length, 1); assert.equal(result.conflict, 1); assert.equal(result.outside, 1);
  assert.equal(result.additions[0].name, "爆笑 / 金句");
  s.markers.push({ ...result.additions[0], ticks: String(110n * BigInt(s.timebase)) });
  const second = c.plan(data, s);
  assert.equal(second.repeated, 2); assert.equal(second.additions.length, 0);
});
test("invalid data and mismatched sequences stop before writing", () => {
  const valid = shoot([mark("a", 100)]);
  for (const raw of ["bad", "null", "[]", shoot([mark("a", 1), mark("a", 2)]), shoot([mark("a", 1.5)]), shoot([mark("a", 1, { lookbackFrames: -1 })]), shoot([], { isTest: true }), shoot([], { format: "__proto__" })]) assert.throws(() => c.parse(raw));
  assert.throws(() => c.plan(c.parse(valid), state("30")), /影格率/);
  assert.throws(() => c.plan(c.parse(valid), state("29.97 NDF")), /顯示格式/);
  assert.throws(() => c.plan(c.parse(valid), state("29.97 DF", 0, 0)), /長度/);
  assert.throws(() => c.exactFrames("1", "100", "start"), /完整影格/);
});
function mock() {
  const s = state(); let transactions = 0, fail = false;
  const owner = { getMarkers: () => s.markers.map(m => ({ getStart: () => ({ ticks: m.ticks }), getComments: () => m.comments, getName: () => m.name })),
    createAddMarkerAction: (name, type, start, duration, comments) => ({ name, ticks: start.ticks, comments }) };
  const sequence = { guid: { toString: () => s.sequenceID }, name: "Sequence", getTimebase: async () => s.timebase,
    getZeroPoint: async () => ({ ticks: s.zero }), getEndTime: async () => ({ ticks: s.end }), getSequenceVideoTimeDisplayFormat: async () => ({ type: s.display }) };
  const project = { guid: { toString: () => s.projectID }, getActiveSequence: async () => sequence, lockedAccess: fn => fn(),
    executeTransaction: fn => { transactions++; const actions = []; fn({ addAction: a => actions.push(a) }); if (fail) return false; s.markers.push(...actions); return true; } };
  const host = createHost({ Project: { getActiveProject: async () => project }, Markers: { getMarkers: async () => owner },
    Marker: { MARKER_TYPE_COMMENT: "Comment" }, TickTime: { createWithTicks: ticks => ({ ticks }) } });
  return { host, s, transactions: () => transactions, fail: () => { fail = true; } };
}
test("adapter imports once in one transaction, then skips repeats", async () => {
  const m = mock(), raw = shoot([mark("a", 100), mark("b", 200)]);
  const review = await m.host.preview(raw);
  assert.equal(await m.host.commit(review, raw, true), 2);
  assert.equal(m.transactions(), 1);
  const second = await m.host.preview(raw);
  assert.equal(second.plan.repeated, 2);
  assert.equal(await m.host.commit(second, raw, true), 0);
  assert.equal(m.transactions(), 1);
});
test("adapter refuses changed file, changed sequence and missing alignment", async () => {
  const m = mock(), raw = shoot([mark("a", 100)]), review = await m.host.preview(raw);
  await assert.rejects(m.host.commit(review, raw, false), /對齊/);
  await assert.rejects(m.host.commit(review, raw + " ", true), /JSON 已改變/);
  m.s.sequenceID = "other";
  await assert.rejects(m.host.commit(review, raw, true), /時間線或標記已改變/);
  assert.equal(m.transactions(), 0);
});
test("host failure is never reported as successful import", async () => {
  const m = mock(), raw = shoot([mark("a", 100)]), review = await m.host.preview(raw);
  m.fail(); await assert.rejects(m.host.commit(review, raw, true), /未完成匯入/);
  assert.equal(m.s.markers.length, 0);
});
test("audio ending between frames includes only frames before the sequence end", () => {
  const s = state(); s.end = String(BigInt(s.timebase) * 300n + 1n);
  const p = c.plan(c.parse(shoot([mark("a", 300), mark("b", 301)], { lookback: 0 })), s);
  assert.equal(p.additions.length, 1); assert.equal(p.additions[0].frame, 300); assert.equal(p.outside, 1);
});
test("shipped demonstration has the three advertised timecodes", () => {
  const fs = require("node:fs"), path = require("node:path");
  const data = c.parse(fs.readFileSync(path.join(__dirname, "../示範標記.json"), "utf8"));
  assert.deepEqual(c.plan(data, state()).additions.map(m => m.tc), ["00:00:03;00", "00:00:08;00", "00:00:10;00"]);
});
